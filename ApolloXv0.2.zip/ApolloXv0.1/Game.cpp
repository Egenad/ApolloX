/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.cpp
 * Author: shiro
 * 
 * Created on 23 de abril de 2018, 13:44
 */

#include "Game.h"

Game* Game::pinstance=0;

Game* Game::Instance(){
    if(pinstance==0){
        pinstance=new Game;
    }
    
    return pinstance;
}

void Game::setState(Estado* state){
    this->state=state;
}

void Game::update(){
    state->handleInput();
}

void Game::draw(){
    state->draw();
}

Game::Game() {
}

Game::Game(const Game& orig) {
}

Game::~Game() {
}

