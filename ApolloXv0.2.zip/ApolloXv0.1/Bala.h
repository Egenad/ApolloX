/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bala.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:32
 */

#ifndef BALA_H
#define BALA_H

class Bala {
public:
    Bala();
    Bala(const Bala& orig);
    virtual ~Bala();
private:

//protected:    
    //int tipo;
    //sprite
    //int danyo
    //angulo
    //int velocidad
};

#endif /* BALA_H */

