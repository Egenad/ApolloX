/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPC.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:34
 */

#ifndef NPC_H
#define NPC_H

class NPC {
public:
    NPC();
    NPC(const NPC& orig);
    virtual ~NPC();
private:

};

#endif /* NPC_H */

