/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Escudo.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:32
 */

#ifndef ESCUDO_H
#define ESCUDO_H

class Escudo {
public:
    Escudo();
    Escudo(const Escudo& orig);
    virtual ~Escudo();
private:

};

#endif /* ESCUDO_H */

