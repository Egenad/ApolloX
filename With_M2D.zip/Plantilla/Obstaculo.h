/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Obstaculo.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:32
 */

#ifndef OBSTACULO_H
#define OBSTACULO_H

class Obstaculo {
public:
    Obstaculo();
    Obstaculo(const Obstaculo& orig);
    virtual ~Obstaculo();
private:

};

#endif /* OBSTACULO_H */

