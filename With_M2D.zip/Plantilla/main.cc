#include <iostream>
#include "Nave.h"
#include "Estado.h"
#include "Motor2D.h"
#include "RenderWindow.h"
#include "Vector2f.h"
#include "Clock.h"
#include "Event.h"
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#define d 300
#define updateTickTime 15

//Motor2D: Sprite, RenderWindow, Vector2f, Clock, Event

void render_interpolacion(m2D::RenderWindow &, Estado &, Estado &, float , Nave &);

int main()
{
    //Ventana 
    m2D::RenderWindow window;
    
    //Limito el numero de fps
    window.setFramerateLimit(60);

    /*Crear nave*/
    m2D::Texture text("./resources/spritesheet.png");
    m2D::Sprite s_nave(text);
    s_nave.setOrigin(110/2,400/2);
    s_nave.setTextureRect(0,0,110,440);
    s_nave.setPosition(350, 350);
    s_nave.scale(0.5, 0.5);
   
    Nave * nave = new Nave(320, 800, s_nave);
     
    /*Inicializar clock*/
    m2D::Clock clock;
    m2D::Vector2f coord_nave(nave->get_posx(), nave->get_posy());
    m2D::Vector2f nuevas;
    Estado * estado_ant = new Estado(coord_nave);
    Estado * nuevoEstado;
       
    bool mov=false;
    
    //Bucle del juego
    while (window.isOpen()){      
        
        //Interpolacion
        
        if(mov == true){
            
            float p = (clock.getElapsedTimeAsSeconds()/updateTickTime);
            if(p>1){
                estado_ant=nuevoEstado;
                
                //mover nave final
                mov=false;
                clock.restart();
            }
            if(p>1){
                p = 1.f;
            }
            
            render_interpolacion(window, *estado_ant, *nuevoEstado, p, *nave);         
            
        }
        
        //Bucle de obtención de eventos
        m2D::Event event;
        
        while (window.pollEvent(event))
        {
            switch(event.getEventType()){
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                break;
                    
                //Se pulsó una tecla, imprimo su codigo
                case sf::Event::KeyPressed:
                   
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.getKey()) {
                        
                        //Mapeo del cursor

                        case sf::Keyboard::Right:
                            
                            nuevas.setVectorX(nave->get_posx()+d);
                            nuevas.setVectorY(nave->get_posy());
                            nuevoEstado = new Estado(nuevas);
                            mov=true;
                            clock.restart();
                        break;
                        
                        case sf::Keyboard::Left:
                            nuevas.setVectorX(nave->get_posx()-d);
                            nuevas.setVectorY(nave->get_posy());
                            nuevoEstado = new Estado(nuevas);
                            mov=true;
                            clock.restart();
                        break;
                        
                        case sf::Keyboard::Up:
                            nuevas.setVectorX(nave->get_posx());
                            nuevas.setVectorY(nave->get_posy()-d);
                            nuevoEstado = new Estado(nuevas);
                            mov=true;
                            clock.restart();
                        break;
                        
                        case sf::Keyboard::Down:
                            nuevas.setVectorX(nave->get_posx());
                            nuevas.setVectorY(nave->get_posy()+d);
                            nuevoEstado = new Estado(nuevas);
                            mov=true;
                            clock.restart();
                        break;
                      
                        
                        //Tecla ESC para salir
                        case sf::Keyboard::Escape:
                            window.close();
                        break;
                        
                        //Cualquier tecla desconocida se imprime por pantalla su código
                        default:
                            std::cout << event.getKey() << std::endl;
                        break;
                              
                    }
                break;
            }          
        }
         
        window.clear();
      
        window.draw(nave->get_sprite());
        
        window.display();
    }

    return 0;
}

void render_interpolacion(m2D::RenderWindow &window, Estado &antiguo, Estado &nuevo, float p, Nave &nave){  
                
    window.clear();
    
    float x1 = antiguo.get_coord_nave().getVectorX();
    float x2 = nuevo.get_coord_nave().getVectorX();
    //std::cout << "x1: " << x1 << " x2: " << x2 << std::endl;
    int xalt= x1*(1-p)+x2*p;
    //int xalt = xi;
    float y1 = antiguo.get_coord_nave().getVectorY();
    float y2 = nuevo.get_coord_nave().getVectorY();
    int yalt = y1*(1-p)+y2*p;
    
    nave.move(xalt, yalt);

    window.draw(nave.get_sprite());
 
}