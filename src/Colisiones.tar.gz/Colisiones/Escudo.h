/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Escudo.h
 * Author: raquel
 *
 * Created on 23 de marzo de 2018, 11:47
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#ifndef ESCUDO_H
#define ESCUDO_H

class Escudo {
public:
    Escudo();
    Escudo (int, int, sf::Sprite);
    void set_sprite(sf::Sprite);
    void set_estado(int);
    int get_posx();
    int get_posy();
    sf::Sprite get_sprite();
    int get_estado();
    void move();
    Escudo(const Escudo& orig);
    virtual ~Escudo();
private:
    int pos_x;
    int pos_y;
    sf::Sprite sprite;
    int estado;

};

#endif /* ESCUDO_H */

