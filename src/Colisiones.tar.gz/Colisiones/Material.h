/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Material.h
 * Author: raquel
 *
 * Created on 23 de marzo de 2018, 11:40
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#ifndef MATERIAL_H
#define MATERIAL_H

class Material {
public:
    Material();
    Material (int, int, sf::Sprite);
    void set_sprite(sf::Sprite);
    void set_estado(int);
    int get_posx();
    int get_posy();
    sf::Sprite get_sprite();
    int get_estado();
    void move();
    Material(const Material& orig);
    virtual ~Material();
private:
    int pos_x;
    int pos_y;
    sf::Sprite sprite;
    int estado;

};

#endif /* MATERIAL_H */

