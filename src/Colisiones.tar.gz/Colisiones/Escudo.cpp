/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Escudo.cpp
 * Author: raquel
 * 
 * Created on 23 de marzo de 2018, 11:47
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#include "Escudo.h"

Escudo::Escudo() {
   pos_x=0;
    pos_y=0;
    estado=1;
}
Escudo::Escudo (int x, int y, sf::Sprite s ){
        pos_x=x;
        pos_y=y;
        estado=1;
        
        sprite = s;
        sprite.setPosition(x, y);
}
void Escudo::set_sprite(sf::Sprite s){
    sprite = s;
}
void Escudo::set_estado(int d){
    estado=d;
}
int Escudo::get_posx(){
    return pos_x;
}
int Escudo::get_posy(){
    return pos_y;
}
sf::Sprite Escudo::get_sprite(){
    return sprite;
}
int Escudo::get_estado(){
    return estado;
}
void Escudo::move(){
    if(pos_y<880){
        pos_y=pos_y+5;
    }else{
        pos_y=200;
    }
    
    sprite.setPosition(pos_x,pos_y);
}

Escudo::Escudo(const Escudo& orig) {
}

Escudo::~Escudo() {
}

