/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Obstaculo.h
 * Author: raquel
 *
 * Created on 23 de marzo de 2018, 11:35
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#ifndef OBSTACULO_H
#define OBSTACULO_H

class Obstaculo {
public:
    Obstaculo();
    Obstaculo (int, int, sf::Sprite);
    int get_posx();
    int get_posy();
    void set_estado(int);
    void set_sprite(sf::Sprite);
    sf::Sprite get_sprite();
    int get_estado();
    void move();
    Obstaculo(const Obstaculo& orig);
    virtual ~Obstaculo();
private:
    int pos_x;
    int pos_y;
    sf::Sprite sprite;
    int estado;

};

#endif /* OBSTACULO_H */

