#include <iostream>
#include <SFML/Graphics.hpp>
#include "Nave.h"
#include "Alien.h"
#include "Escudo.h"
#include "Material.h"
#include "Obstaculo.h"

#define salto 17

int main()
{
    //Ventana 
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");

    
    /*Crear nave*/
     sf::Texture tex_nave;
    if (!tex_nave.loadFromFile("resources/spritesheet.png"))
    {
        std::cerr << "Error cargando la imagen spritessheet.png";
        exit(0);
    }

    sf::Sprite s_nave(tex_nave);
    s_nave.setOrigin(110/2,400/2);
    s_nave.setTextureRect(sf::IntRect(0, 0, 110, 400));
    s_nave.scale(0.5, 0.5);
    
    sf::Sprite s_nave_esc(tex_nave);
    s_nave_esc.setOrigin(110/2,400/2);
    s_nave_esc.setTextureRect(sf::IntRect(2*110+2, 0, 110, 400));
    s_nave_esc.scale(0.5, 0.5);
    
    Nave nave(320, 800, s_nave);
    
     /*Crear alien, obstaculo, escudo y material*/
    //Sprite enemigo
    
    //Cargar imagen textura
    
    sf::Texture tex;
    if (!tex.loadFromFile("resources/sprites.png"))
    {
        std::cerr << "Error cargando la imagen enemigo.png";
        exit(0);
    }
    
    
    sf::Sprite block(tex);
    block.setOrigin(32/2,32/2);
    block.setTextureRect(sf::IntRect(0*32, 5*32, 32, 32));
    
    Alien alien(150, 200, block);
    
    
    block.setTextureRect(sf::IntRect(2*32+16, 5*32, 32, 32));
    
    Escudo escudo(250, 200, block);
    
    
    block.setTextureRect(sf::IntRect(5*32, 5*32, 32, 32));
    
    Material material(350, 200, block);
    
    
    block.setTextureRect(sf::IntRect(7*32+16, 5*32, 32, 32));
    
    Obstaculo obstaculo(450, 200, block);
    
    /*Inicializar clock*/
    sf::Clock clock;
    sf::Clock clock2;
    sf::Clock clock3;
    sf::Clock clock4;
    bool mov=false;
    bool nav=true;
    
    //Bucle del juego
    while (window.isOpen())
    {
        //Movimiento objetos
        if (clock.getElapsedTime().asSeconds() > 0.1f && mov==true){
             
            alien.move();
            escudo.move();
            material.move();
            obstaculo.move();
    
            clock.restart();
        }
        //Nave golpeada
        if (clock2.getElapsedTime().asSeconds() > 0.3f && nave.get_estado()==1){
             
            if(nav==true){
                nav=false;
            }else{
                nav=true;
            }
    
            clock2.restart();
        }
        
        if (clock3.getElapsedTime().asSeconds() > 5.0f){
            if(nave.get_estado()==1){
                nave.set_estado(2);
                nav=true;
            }
            
            clock3.restart();
        }
        //escudo
        if (clock4.getElapsedTime().asSeconds() > 10.0f ){
            if(nave.get_estado()==3){
                nave.set_sprite(s_nave);
                nave.set_estado(2);
            }
            
            clock4.restart();
        }
        
        //Colision con algun objeto
        
        if(nave.get_posx() > (alien.get_posx()-25) && nave.get_posx() < (alien.get_posx()+25)){
            if(alien.get_posy()>nave.get_posy()-100 && alien.get_posy()<nave.get_posy()){
                if(nave.get_estado()==2 && alien.get_estado()==1){
                    //Nave golpeada
                    nave.set_estado(1);
                }
            }    
        }else if(nave.get_posx() > (escudo.get_posx()-25) && nave.get_posx() < (escudo.get_posx()+25)){
            if(escudo.get_posy()>nave.get_posy()-100 && escudo.get_posy()<nave.get_posy()){
               if(escudo.get_estado()==1){
                    //Nave con escudo
                    escudo.set_estado(0); 
                    nave.set_sprite(s_nave_esc);
                    nave.set_estado(3);
               }
            }    
        }else if(nave.get_posx() > (material.get_posx()-25) && nave.get_posx() < (material.get_posx()+25)){
            if(material.get_posy()>nave.get_posy()-100 && material.get_posy()<nave.get_posy()){
               if(material.get_estado()==1){
                    //desaparece el material
                    material.set_estado(0);  
               }
            }    
        }else if(nave.get_posx() > (obstaculo.get_posx()-25) && nave.get_posx() < (obstaculo.get_posx()+25)){
            if(obstaculo.get_posy()>nave.get_posy()-100 && obstaculo.get_posy()<nave.get_posy()){
                if(nave.get_estado()==2 && obstaculo.get_estado()==1){
                    //nave muere
                    nave.set_estado(0);
                    mov=false;
                }
            }    
        }
        
        
         
       
        //Bucle de obtención de eventos
        sf::Event event;
        while (window.pollEvent(event))
        {
            
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                //Se pulsó una tecla, imprimo su codigo
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        //Mapeo del cursor
                        case sf::Keyboard::Right:
                            nave.move(salto,0);
                        break;

                        case sf::Keyboard::Left:
                            nave.move(-salto,0); 
                        break;
                        
                        case 57:
                            //disparo
                            if(mov==true){
                                mov=false;
                            }else{
                                mov=true;
                            }
                        break;
       
                        //Tecla ESC para salir
                        case sf::Keyboard::Escape:
                            window.close();
                        break;
                        
                        //Cualquier tecla desconocida se imprime por pantalla su código
                        default:
                            std::cout << event.key.code << std::endl;
                        break;
                              
                    }

            }
            
        }

        window.clear();
        window.draw(alien.get_sprite());
        if(escudo.get_estado()==1){
            window.draw(escudo.get_sprite());
        }
        
        if(material.get_estado()==1){
            window.draw(material.get_sprite());
        }
        window.draw(obstaculo.get_sprite());
        
        if(nave.get_estado() != 0 && nav==true){
            window.draw(nave.get_sprite());
        }
        
        window.display();
    }

    return 0;
}