/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alien.cpp
 * Author: raquel
 * 
 * Created on 21 de marzo de 2018, 14:07
 */
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Alien.h"

Alien::Alien() {
    pos_x=0;
    pos_y=0;
    estado=0;
}
Alien::Alien (int x, int y, sf::Sprite s ){
        pos_x=x;
        pos_y=y;
        estado=1;
        
        sprite = s;
        sprite.setPosition(x, y);
}
void Alien::set_sprite(sf::Sprite s){
    sprite = s;
}
void Alien::set_estado(int d){
    estado=d;
}
int Alien::get_posx(){
    return pos_x;
}
int Alien::get_posy(){
    return pos_y;
}
sf::Sprite Alien::get_sprite(){
    return sprite;
}
int Alien::get_estado(){
    return estado;
}
void Alien::move(){
    if(pos_y<880){
        pos_y=pos_y+5;
    }else{
        pos_y=200;
    }
    
    
    sprite.setPosition(pos_x,pos_y);
}

Alien::Alien(const Alien& orig) {
}

Alien::~Alien() {
}

