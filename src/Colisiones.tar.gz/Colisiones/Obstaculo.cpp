/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Obstaculo.cpp
 * Author: raquel
 * 
 * Created on 23 de marzo de 2018, 11:35
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#include "Obstaculo.h"

Obstaculo::Obstaculo() {
    pos_x=0;
    pos_y=0;
    estado=1;
}
Obstaculo::Obstaculo (int x, int y, sf::Sprite s ){
        pos_x=x;
        pos_y=y;
        
        sprite = s;
        sprite.setPosition(x, y);
}
void Obstaculo::set_sprite(sf::Sprite s){
    sprite = s;
}
void Obstaculo::set_estado(int d){
    estado=d;
}
int Obstaculo::get_posx(){
    return pos_x;
}
int Obstaculo::get_posy(){
    return pos_y;
}
sf::Sprite Obstaculo::get_sprite(){
    return sprite;
}
int Obstaculo::get_estado(){
    return estado;
}
void Obstaculo::move(){
    if(pos_y<880){
        pos_y=pos_y+5;
    }else{
        pos_y=200;
    }
    
    sprite.setPosition(pos_x,pos_y);
}

Obstaculo::Obstaculo(const Obstaculo& orig) {
}

Obstaculo::~Obstaculo() {
}

