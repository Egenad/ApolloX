#include <iostream>
#include <SFML/Graphics.hpp>
#include "Nave.h"
#include "Material.h"

#define salto 17

int main()
{
    //Ventana 
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");

    
    /*Crear nave*/
    sf::Texture tex_nave;
    if (!tex_nave.loadFromFile("resources/spritesheet.png"))
    {
        std::cerr << "Error cargando la imagen spritessheet.png";
        exit(0);
    }

    sf::Sprite s_nave(tex_nave);
    s_nave.setOrigin(110/2,145/2);
    s_nave.setTextureRect(sf::IntRect(0, 0, 110, 145));
    s_nave.scale(0.5, 0.5);
    
    Nave nave(320, 800, s_nave);
    
    
    int reparar;
    int* materiales_reparacion;
    int* materiales;
    int vida;
    
    std::cout << "Prueba reparacion de la nave"<< std::endl;
    std::cout << "Para ver los materiales necesarios para reparar la nave y los materiales que tienes actualmente --> espacio" << std::endl;
    std::cout << "Reparar nave --> F " << std::endl;
    std::cout << "Recoger materiales:" << std::endl;
    std::cout << "Carbon --> Q " << std::endl;
    std::cout << "Hierro --> W " << std::endl;
    std::cout << "Titanio --> E " << std::endl;
    std::cout << "Magnesio --> R " << std::endl;
    std::cout << "Aumentar vida --> Up " << std::endl;
    std::cout << "Disminuir vida --> Down " << std::endl;
    
    
    //Bucle del juego
    while (window.isOpen())
    {
        
        //Bucle de obtención de eventos
        sf::Event event;
        while (window.pollEvent(event))
        {
            
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                //Se pulsó una tecla, imprimo su codigo
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        //Mapeo del cursor
                        case sf::Keyboard::Up:
                            vida=nave.aumentar_vida(10);
                            std::cout << "Vida aumentada --> Vida actual: " << nave.get_vida() << std::endl;
                        break;

                        case sf::Keyboard::Down:
                            vida=nave.reducir_vida(10);
                            std::cout << "Vida reducida --> Vida actual: " << nave.get_vida() << std::endl;
                        break;
                        
                        case 57:
                            materiales_reparacion=nave.calcular_reparacion();
                            
                            std::cout << "Total materiales Necesarios para la reparacion"<< std::endl;
                            std::cout << "Carbon: " << materiales_reparacion[0] << std::endl;
                            std::cout << "Hierro: " << materiales_reparacion[1]<< std::endl;
                            std::cout << "Titanio: " << materiales_reparacion[2] << std::endl;
                            std::cout << "Magnesio: " << materiales_reparacion[3] << std::endl;
                            
                            materiales=nave.get_materiales();
                            
                            std::cout << "Total materiales Disponibles:"<< std::endl;
                            std::cout << "Carbon: " << materiales[0] << std::endl;
                            std::cout << "Hierro: " << materiales[1]<< std::endl;
                            std::cout << "Titanio: " << materiales[2] << std::endl;
                            std::cout << "Magnesio: " << materiales[3] << std::endl;         
                            
                            std::cout << "Pulsa F para reparar la nave " << std::endl;
                            std::cout << "Para conseguir materiales: carbon(Q), hierro(W), titanio(E) y magnesio(R)" << std::endl;
                            
                        break;
                        
                        case 16:
                            nave.coger_material(0);
                            std::cout << "Has cogido Carbon"<< std::endl;
                        break;
                        
                        case 22:
                            nave.coger_material(1);
                            std::cout << "Has cogido Hierro"<< std::endl;
                        break;
                        
                        case 4:
                            nave.coger_material(2);
                            std::cout << "Has cogido Titanio"<< std::endl;
                        break;
                        
                        case 17:
                            nave.coger_material(3);
                            std::cout << "Has cogido Magnesio"<< std::endl;
                        break;
                        
                        case 5:
                            std::cout << "Vida Actual --> "<< nave.get_vida()<< std::endl;
                            std::cout << "Reparando nave..."<< std::endl;
                            reparar=nave.reparar_nave();
                            if(reparar==1){
                                std::cout << "La nave se ha reparado --> vida actual: "<< nave.get_vida() << std::endl;
                            }else{
                                std::cout << "No se ha podido reparar la nave"<< std::endl;
                            }
                        break;
                            
                        //Tecla ESC para salir
                        case sf::Keyboard::Escape:
                            window.close();
                        break;
                        
                        //Cualquier tecla desconocida se imprime por pantalla su código
                        default:
                            std::cout << event.key.code << std::endl;
                        break;
                              
                    }

            }
            
        }

        window.clear();
       
        window.draw(nave.get_sprite());
        
        
        window.display();
    }

    return 0;
}