/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nave.cpp
 * Author: raquel
 * 
 * Created on 27 de febrero de 2018, 18:18
 */
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Nave.h"

Nave::Nave (){
    coord_x=0;
    coord_y=0;
    estado=2;
    materiales = new int[4];
    vida_total=100;
    vida_actual=vida_total;
    
}
Nave::Nave (int x, int y, sf::Sprite s ){
        coord_x=x;
        coord_y=y;
        estado=2;
        materiales = new int[4];
        vida_total=100;
        vida_actual=vida_total;
        
        for(int i=0; i<4; i++){
            materiales[i]=0;
        }
        
        sprite = s;
        sprite.setPosition(x, y);
    }

int Nave::get_posx(){
    return coord_x;
}
int Nave::get_posy(){
    return coord_y;
}
void Nave::set_sprite(sf::Sprite s){
    sprite = s;
    sprite.setPosition(coord_x, coord_y);
}
void Nave::change_sprite(){
    
    float vida = vida_actual/vida_total;
    
    if(vida <= 0.25 ){
        sprite.setTextureRect(sf::IntRect(6*112, 0, 112, 145));
    }else if(vida>0.25 && vida<=0.5){
        sprite.setTextureRect(sf::IntRect(4*112, 0, 112, 145));
    }else if(vida>=0.5 && vida<=0.75){
        sprite.setTextureRect(sf::IntRect(2*112, 0, 112, 145));
    }else if(vida>0.75){
        sprite.setTextureRect(sf::IntRect(0, 0, 112, 145));
    }
}
sf::Sprite Nave::get_sprite(){
    return sprite;
}
void Nave::move(int x, int y){
    coord_x=coord_x+x;
    coord_y=coord_y+y;
    
    sprite.move(x,y);
}
void Nave::set_estado(int d){
    estado=d;
}
int Nave::get_estado(){
    return estado;
}
void Nave::coger_material(int t){
    materiales[t]+=1;
}
int* Nave::get_materiales(){
    return materiales;
}
float Nave::get_vida(){
    return vida_actual;
}
float Nave::reducir_vida(int c){
    vida_actual -= c;
    
    if(vida_actual<0){
        vida_actual=0;
    }
    change_sprite();
    return vida_actual;
}
float Nave::aumentar_vida(int c){
    vida_actual += c;
    
    if(vida_actual>vida_total){
        vida_actual=vida_total;
    }
    
    change_sprite();
    return vida_actual;
}
int* Nave::calcular_reparacion(){
    int* reparacion;
    reparacion= new int[4];
    
    float vida = vida_actual/vida_total;
    
    if(vida <= 0.25 ){
        reparacion[0]=8;
        reparacion[1]=8;
        reparacion[2]=7;
        reparacion[3]=5;
    }else if(vida>0.25 && vida<=0.5){
        reparacion[0]=7;
        reparacion[1]=5;
        reparacion[2]=3;
        reparacion[3]=2;
    }else if(vida>=0.5 && vida<=0.75){
        reparacion[0]=3;
        reparacion[1]=3;
        reparacion[2]=2;
        reparacion[3]=1;
    }else if(vida>0.75 && vida<1){
        reparacion[0]=2;
        reparacion[1]=1;
        reparacion[2]=0;
        reparacion[3]=0;
    }else{
        reparacion[0]=0;
        reparacion[1]=0;
        reparacion[2]=0;
        reparacion[3]=0;
    }
    
    return reparacion;
}
int Nave::reparar_nave(){
    int* reparacion;
    reparacion = calcular_reparacion();
    int reparar = 0;
    
    if(materiales[0]>= reparacion[0] && materiales[1]>=reparacion[1] && materiales[2]>=reparacion[2] && materiales[3]>=reparacion[3]){
       
        vida_actual = vida_total;
        
        
        materiales[0] -= reparacion[0];
        materiales[1] -= reparacion[1];
        materiales[2] -= reparacion[2];
        materiales[3] -= reparacion[3];
        
        reparar = 1;
    }
    
    return reparar;
    
}




Nave::Nave(const Nave& orig) {
}

Nave::~Nave() {
}

