/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Material.cpp
 * Author: raquel
 * 
 * Created on 23 de marzo de 2018, 11:40
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#include "Material.h"

Material::Material() {
    pos_x=0;
    pos_y=0;
    estado=1;
    tipo=-1;
}
Material::Material (int x, int y, sf::Sprite s, int t ){
        pos_x=x;
        pos_y=y;
        estado=1;
        tipo=t;
        
        sprite = s;
        sprite.setPosition(x, y);
}
void Material::set_sprite(sf::Sprite s){
    sprite = s;
}
void Material::set_estado(int d){
    estado=d;
}
int Material::get_posx(){
    return pos_x;
}
int Material::get_posy(){
    return pos_y;
}
sf::Sprite Material::get_sprite(){
    return sprite;
}
int Material::get_estado(){
    return estado;
}
int Material::get_tipo(){
    return tipo;
}
void Material::move(){
    if(pos_y<880){
        pos_y=pos_y+5;
    }else{
        pos_y=200;
        estado=1;
    }
    
    sprite.setPosition(pos_x,pos_y);
}
Material::Material(const Material& orig) {
}

Material::~Material() {
}

