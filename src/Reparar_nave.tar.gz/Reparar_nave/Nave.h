/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nave.h
 * Author: raquel
 *
 * Created on 27 de febrero de 2018, 18:18
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#ifndef NAVE_H
#define NAVE_H

class Nave {
    
public:
    Nave ();
    Nave (int, int, sf::Sprite);
    void set_sprite(sf::Sprite);
    void set_estado(int);
    void coger_material(int);
    int get_posx();
    int get_posy();
    sf::Sprite get_sprite();
    void change_sprite();
    int get_estado();
    int* get_materiales();
    float get_vida();
    float reducir_vida(int);
    float aumentar_vida(int);
    int reparar_nave();
    int* calcular_reparacion();
    void move(int, int);
    Nave(const Nave& orig);
    virtual ~Nave();
private:
    int coord_x;
    int coord_y;
    float vida_total;
    float vida_actual;
    sf::Sprite sprite;
    int estado;
    int *materiales;
};

#endif /* NAVE_H */

