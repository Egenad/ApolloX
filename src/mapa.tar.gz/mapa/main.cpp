/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: shiro
 *
 * Created on 24 de marzo de 2018, 19:13
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <time.h>


int main() {
    
    
    srand(time(NULL));
    
    sf::RenderWindow window(sf::VideoMode(640, 1024), "mapa");
    
    sf::Texture tex;
    if (!tex.loadFromFile("resources/fondo1.png")){
        std::cerr << "Error cargando la imagen fondo.jpg";
        exit(0);
    }
    
    sf::Vector2u tamanyo=tex.getSize();
    
    //SPRITES DEL FONDO
    sf::Sprite *sprites=new sf::Sprite[3];
    for(int i=0;i<3;i++){
        sprites[i].setTexture(tex);
        sprites[i].setTextureRect(sf::IntRect(0,0, tamanyo.x,tamanyo.y));
        int donde=(1024-tamanyo.y)-(i*tamanyo.y);
        sprites[i].setPosition(20, donde);
    }
    
    //NAVE
    sf::Texture tex2;
    if (!tex2.loadFromFile("resources/spritesheet.png")){
        std::cerr << "Error cargando la imagen fondo.jpg";
        exit(0);
    }
    
    sf::Sprite nave(tex2);
    nave.setTextureRect(sf::IntRect(0,0,110,150));
    nave.scale(0.7,0.7);
    nave.setPosition(285,874);
    
    sf::Clock reloj;
    bool mueve=false;
    bool stop=false;
    
    //VISTA
    sf::View vista(sf::FloatRect(0,0,640,1024));
    vista.setCenter(320,512);
    
    int last=0;
    int cont=1;
    
    
    //CREACION DE LOS BICHOS DEL MAPA
    std::ifstream openfile("resources/mapa.txt");
    std::string linea;
    int cuantosEnemigos;
    int longMapa;
    int cualLinea=0;
    sf::Sprite *bichos;
    
    if(openfile.is_open()){
        
        while(!openfile.eof()){
            
            std::getline(openfile,linea);
            switch(cualLinea){
                case 0:
                    longMapa=atoi(linea.c_str());
                    break;
                case 1:
                    cuantosEnemigos=atoi(linea.c_str());
                    bichos=new sf::Sprite[cuantosEnemigos];
                    break;
                    
                default:
                    bichos[cualLinea-2].setTexture(tex2);
                    if(linea=="0"){
                        bichos[cualLinea-2].setTextureRect(sf::IntRect(250,0, 120,100));
                    }else if(linea=="1"){
                        bichos[cualLinea-2].setTextureRect(sf::IntRect(350,0, 120,100));
                    }else{
                        bichos[cualLinea-2].setTextureRect(sf::IntRect(450,0, 120,100));
                    }
                    
                    //aleatorio
                    int x=rand() % 610;
                    int y=-((longMapa/cuantosEnemigos)*cualLinea);  
                    bichos[cualLinea-2].setPosition(x,y);
                    break;
            }
            cualLinea++;
        }
        
        openfile.close();
    }
    
    
     while (window.isOpen()){
         
         if (reloj.getElapsedTime().asSeconds() > 0.01f&&mueve==true&&stop==false ){
             nave.move(0,-2);
             sf::Vector2f posicion1=nave.getPosition();
             //std::cout << posicion1.y <<std::endl;
             reloj.restart();
         }
         
         
        sf::Event event;
        while (window.pollEvent(event))
        {      
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        case 57:
                            mueve=true;
                            reloj.restart();
                            break;
                    }
            }
        }
        
        
        //la nave es la que se mueve loco
        sf::Vector2f posicion=nave.getPosition();

        int dondeCentro=posicion.y-362;
        if(abs(dondeCentro)<(longMapa+1024)){
            vista.setCenter(320,dondeCentro);
        }else{
            stop=true;
        }
        
        int doko=(tamanyo.y-(tamanyo.y*cont));
        if(dondeCentro==doko){
            
            cont++;
            int dondeAhora=dondeCentro-(tamanyo.y*2);
            sprites[last].setPosition(20,dondeAhora);
            last++;
            if(last==3){
                last=0;
            }
            
        }
        
        window.setView(vista);
        window.clear();
        for(int j=0;j<3;j++){
            window.draw(sprites[j]);
        }
        window.draw(nave);
        for(int k=0;k<cuantosEnemigos;k++){
            window.draw(bichos[k]);
        }
        window.display();

    }
    
    return 0;
}

