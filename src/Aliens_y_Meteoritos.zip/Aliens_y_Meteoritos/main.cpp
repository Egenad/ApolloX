
#include "Enemigo.hpp"
#include "Bullet.hpp"
#include "Nave.hpp"
#include "Meteorito.hpp"
#include <SFML/Graphics.hpp>
#include <list>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>


int main()
{
    //SEMILLA PARA LOS RAND
    srand(time(NULL));
    int i=0;

    //VECTOR ENEMIGOS
    std::vector<Enemigo*> alo;
    
    //VECTOR DE METEORITOS
    std::vector<Meteorito*> meteoritos; 
    
    //CREAMOS VENTANA
    sf::RenderWindow window(sf::VideoMode(640, 880), "Aliens!");
    window.setVerticalSyncEnabled(true);
    
    //RELOJ PARA SINCRONIZAR LOS FRAMES
    sf::Clock synchronice_timer;
    sf::Clock apa;
    sf::Clock res;
    sf::Clock resmete;
    
    //Definimos las clases
    Nave nave(sf::Vector2f(50, 50));
    
    nave.setPos(sf::Vector2f(320, 650));
    
    
    //---------variables setting---------------
    bool isFiring=false;
    float grados=90.0f;//movimiento del alien
    float grados1=180.0f;
    float grados2=135.0f;
    
    //-----------------
    
    
    
    //Bucle principal
    while(window.isOpen())
    {   
        
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            
            int ms = 10;
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
                nave.move(sf::Vector2f(-ms,0));
            }
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
                nave.move(sf::Vector2f(ms,0));
            }
            
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
                if(nave.getX()>0)
                nave.move(sf::Vector2f(-ms,0));
            }
            
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
                if(nave.getX()<590)
                nave.move(sf::Vector2f(ms,0));
            }
                         
        }
        
    if(res.getElapsedTime().asSeconds()>4){
        //if(i<4){ Para controlar cuanto aliens salen en este caso infinito
        int randx=rand()%(600-100);
        int randtipo=rand()%(3-0)+1;
        Enemigo *newEne= new Enemigo(sf::Vector2f(50,50),randtipo);//creamos un enemigo
        alo.push_back(newEne);//VECTOR DE Enemigos
        res.restart();
            
        i++;
       // }
    }
        
    if(resmete.getElapsedTime().asSeconds()>2){
        Meteorito *newMete= new Meteorito();
        meteoritos.push_back(newMete);
        bool cola=false;
        resmete.restart();      
    }
        
        window.clear();
        
        
        for(int g=0;g<alo.size();g++){ //disparo de los aliens
            alo[g]->dispara();

        }
        
        for(int n=0;n<alo.size();n++){ //dibujamos la balas de los aliens
            alo[n]->dibujaBalas(window,nave);
        }
       
          

        
        
        
        
        //MOSTRAR EN PANTALLA
        nave.draw(window);
        
        //recorremos el vector de aliens para moverlo
        for(int n=0;n<alo.size();n++){
            alo[n]->draw(window);
            if(alo[n]->getTipo()==1){
                alo[n]->mov(grados);
                grados=grados+0.006f;
            }
            else if(alo[n]->getTipo()==2){
                alo[n]->mov(grados1);
                grados1=grados1+0.006f;
            }
            else if(alo[n]->getTipo()==3){
                alo[n]->mov(grados2);
                grados2=grados2+0.006f;
            }
        }
        
        for(int n=0;n<meteoritos.size();n++){
                meteoritos[n]->move();
                meteoritos[n]->draw(window);
        }

           
        window.display();
        
        for(int k=0;k<meteoritos.size();k++){
            bool cola=false;
            cola=nave.checkCollMete(*meteoritos[k]);
            if(cola==true){
                std::cout <<nave.getVida() <<std::endl;
            }
        }
        
        
        //SINCRONIZAMOS 30 fps
        while(synchronice_timer.getElapsedTime().asSeconds()<1.0f/30.0f)
        {
            sf::sleep(sf::seconds(1.0f/60.0f));
        }

    }

    return 0;
}