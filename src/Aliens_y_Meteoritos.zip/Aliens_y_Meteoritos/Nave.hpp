/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nave.hpp
 * Author: jose
 *
 * Created on 24 de marzo de 2018, 19:45
 */

#ifndef NAVE_HPP
#define NAVE_HPP
#include "Bullet.hpp"
#include "Meteorito.hpp"
#include <SFML/Graphics.hpp>
#include <iostream>

class Nave {
public:
    Nave(sf::Vector2f size);
    
    void move(sf::Vector2f dir);
    
    int getX();
    int getY();
    
    int getVida();
    
    void setPos(sf::Vector2f newPos);
    bool checkColl(Bullet &bullet);//COLISIONES CON LAS BALAS
    bool checkCollMete(Meteorito &meteorito);//COLISONES CON METEORITOS
    
    void draw(sf::RenderWindow &window);//DIBUJA
    
   
    

    
private:
    sf::RectangleShape nave;
    int vida;
    
  
};

#endif /* NAVE_HPP */

