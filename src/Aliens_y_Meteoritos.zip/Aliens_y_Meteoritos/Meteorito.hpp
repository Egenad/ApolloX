/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Meteorito.hpp
 * Author: jose
 *
 * Created on 19 de abril de 2018, 19:11
 */

#ifndef METEORITO_HPP
#define METEORITO_HPP
#include <SFML/Graphics.hpp>

class Meteorito {
public:
    Meteorito();
    
    sf::CircleShape returnShape();
    void move();
    void draw(sf::RenderWindow &window);
private:
    sf::CircleShape shape_mete;
    int vely; //velocidad de caida
    int tipo; //tipo para indicar el tipo de trayectoria
    int radiomax; //radio maximo del meteorito
    int radiomin; //radio minimo del meteorito
};


#endif /* METEORITO_HPP */

