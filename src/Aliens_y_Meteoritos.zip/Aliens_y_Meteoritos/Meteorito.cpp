/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Meteorito.cpp
 * Author: jose
 * 
 * Created on 19 de abril de 2018, 18:10
 */

#include "Meteorito.hpp"
#include <time.h>


Meteorito::Meteorito() {
    srand(time(NULL));
    radiomax=80;
    radiomin=15;
    vely=6; //velocidad de caida
    float ran1=rand()%(radiomax-radiomin);  //numero aleatorio para radio del meteorito
    if(ran1>50){
        vely=3;
    }
    else if(ran1<50 && ran1>30){
        vely=5;
    }
    float ranx=rand()%700-60; //numero aleatorio para respawn en eje x
    shape_mete.setRadius(ran1);
    shape_mete.setFillColor( sf::Color( 0, 0, 0, 0xFF) );
    shape_mete.setOutlineColor( sf::Color::White );
    shape_mete.setOutlineThickness(2);
    shape_mete.setOrigin(ran1, ran1);
    shape_mete.setPosition(ranx,-radiomax);
            
            //LO Clasificamos en tipos para determinar la trayectoria del meteorito
    if(shape_mete.getPosition().x<=200){
        tipo=1;
    }
    else if(200<shape_mete.getPosition().x && shape_mete.getPosition().x<=400){
        tipo=2;
    }
            
    else if(shape_mete.getPosition().x>400){
        tipo=3;
    }
    
}

sf::CircleShape Meteorito::returnShape(){
    return shape_mete;
}

void Meteorito::move(){
    if(tipo==1){
        shape_mete.move(1,vely);
    }
    else if(tipo==2){
        shape_mete.move(0,vely);
    }
    
    else if(tipo==3){
        shape_mete.move(-1,vely);
    }
}

void Meteorito::draw(sf::RenderWindow &window){
    window.draw(shape_mete);
}


