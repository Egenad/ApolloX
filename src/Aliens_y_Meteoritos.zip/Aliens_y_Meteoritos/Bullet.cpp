/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bullet.cpp
 * Author: jose
 * 
 * Created on 24 de marzo de 2018, 19:42
 */

#include "Bullet.hpp"
#include <SFML/Graphics.hpp>

Bullet::Bullet(sf::Vector2f size) {//CONSTRUCTOR
    bullet.setSize(size);
    bullet.setFillColor(sf::Color::Blue);
}

void Bullet::fire(int speed){
    bullet.move(0,speed); //MOVEMOS LA BALA EN Y negativa (hacia abajo)
}

int Bullet::getLeft(){
    return bullet.getPosition().x + bullet.getSize().x;
    
}

int Bullet::getRight(){
        return bullet.getPosition().x + bullet.getSize().x;
}

int Bullet::getTop(){
        return bullet.getPosition().y;
}

int Bullet::getBottom(){
        return bullet.getPosition().y + bullet.getSize().y;
}

void Bullet::setPos(sf::Vector2f pos){
    bullet.setPosition(pos);
}

void Bullet::draw(sf::RenderWindow &window){
    window.draw(bullet);
}

sf::RectangleShape Bullet::returnShape(){
    return bullet;
}

