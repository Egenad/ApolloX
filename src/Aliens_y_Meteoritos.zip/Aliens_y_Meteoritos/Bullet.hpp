/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bullet.hpp
 * Author: jose
 *
 * Created on 24 de marzo de 2018, 19:42
 */

#ifndef BULLET_HPP
#define BULLET_HPP
#include <SFML/Graphics.hpp>

class Bullet {
public:
    Bullet(sf::Vector2f size); //constru
    
    void fire(int speed);
    
    int getBottom();
    int getLeft();
    int getRight();
    int getTop();
    void setPos(sf::Vector2f pos);
    
    void draw(sf::RenderWindow &window);//renderiza el alien
   
    
    sf::RectangleShape returnShape();//devuelve el shape
    
private:
    sf::RectangleShape bullet;
};

#endif /* BULLET_HPP */

