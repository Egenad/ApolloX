/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Enemigo.hpp
 * Author: jose
 *
 * Created on 24 de marzo de 2018, 19:46
 */

#ifndef ENEMIGO_HPP
#define ENEMIGO_HPP
#include "Bullet.hpp"
#include "Nave.hpp"
#include <SFML/Graphics.hpp>


class Enemigo {
public:
    Enemigo(sf::Vector2f size, int tipo);
    
    
    int getX();
    int getY();
    
   void setPos(int x, int y);
    
    void draw(sf::RenderWindow &window);
    
    void dispara();
    
    void dibujaBalas(sf::RenderWindow &window,Nave &nave);
    
    void mov(float grados);
    sf::Vector2f getPos();
    
    sf::RectangleShape& getShape();
    
    int getTipo();
    
private:
    sf::RectangleShape alien;
    
    sf::Vector2f pos;

    std::vector<Bullet*> balas;//vector balas
    
    sf::Clock dis;
    
    int tipo;

};

#endif /* ENEMIGO_HPP */

