/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Mision.h
 * Author: shiro
 *
 * Created on 26 de marzo de 2018, 15:50
 */

#ifndef MISION_H
#define MISION_H
#include <SFML/Graphics.hpp>

class Mision {
public:
    Mision(int i);
    Mision(const Mision& orig);
    virtual ~Mision();
    
    void juega(sf::RenderWindow &window, Mision &misionAnterior, int i);
    bool getPasado();
    
private:
    bool pasado;
    sf::Text texto;
    sf::Font fuente;
};

#endif /* MISION_H */

