/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Menu.h
 * Author: shiro
 *
 * Created on 26 de marzo de 2018, 14:42
 */

#ifndef MENU_H
#define MENU_H
#include <SFML/Graphics.hpp>

class Menu {
public:
    Menu();
    Menu(const Menu& orig);
    virtual ~Menu();
    
    void draw(sf::RenderWindow &window);
    void moveUp();
    void moveDown();
    int getSeleccionado();
private:
    int seleccionado;
    sf::Font fuente;
    sf::Text *seleccionadores;
};

#endif /* MENU_H */

