/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: shiro
 *
 * Created on 26 de marzo de 2018, 14:28
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include "Menu.h"
#include "Mision.h"
/*
 * 
 */
int main() {
    
    
    sf::RenderWindow window(sf::VideoMode(640, 1024), "desbloqueo");
    Menu menu;
    Mision mision [3]={{0},{1},{2}};
    int a=-1;
    
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {   
            switch(event.type){
                    //Si se recibe el evento de cerrar la ventana la cierro
                    case sf::Event::Closed:
                        window.close();
                        break;
                        
                    case sf::Event::KeyPressed:
                        //Verifico si se pulsa alguna tecla de movimiento
                        switch(event.key.code) {
                            
                            //Mapeo del cursor
                            case sf::Keyboard::Up:
                                menu.moveUp();
                            break;

                            case sf::Keyboard::Down:
                                
                                menu.moveDown();
                            break;
                            
                            case sf::Keyboard::Return:
                                
                                a=menu.getSeleccionado();
                                
                            break;
                            
                            case 0:
                                a=-1;
                            break;
                         
                        }
                        
                    break;
            }
        }
        
        window.clear();
        if(a==-1){
            menu.draw(window);
        }
        
        if(a!=-1){
            if(a==0){
                mision[a].juega(window,mision[a],a);
            }else if(a!=0){
                mision[a].juega(window,mision[a-1],a);
            }
        }
        window.display();
    }
    
    return 0;
}

