/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Mision.cpp
 * Author: shiro
 * 
 * Created on 26 de marzo de 2018, 15:50
 */

#include "Mision.h"
#include <SFML/Graphics.hpp>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <iostream>

Mision::Mision(int i) {
    
    if(!fuente.loadFromFile("resources/Loma.ttf")){
        //handle error
    }
    
    texto.setFont(fuente);
    texto.setColor(sf::Color::Cyan);
    
    std::stringstream ss;
    ss << i;
    std::string str=ss.str();
    texto.setString("Has jugado el nivel "+ str +"!");
    
    texto.setPosition(sf::Vector2f(0,0));
    
    pasado=false;
    
}

Mision::Mision(const Mision& orig) {
}

Mision::~Mision() {
}

void Mision::juega(sf::RenderWindow &window, Mision &misionAnterior,int i){
    
    if(i==0){
        pasado=true;
        std::stringstream ss;
        ss << i;
        std::string str=ss.str();
        texto.setString("Has jugado el nivel "+ str +"!");
    }else{
        
        bool anterior=misionAnterior.getPasado();
        if(anterior==true){
            pasado=true;
            std::stringstream ss;
            ss << i;
            std::string str=ss.str();
            texto.setString("Has jugado el nivel "+ str +"!");
        }else{
            texto.setString("Bloqueado");
        }
    }
    window.draw(texto);
}

bool Mision::getPasado(){
    return pasado;
}
