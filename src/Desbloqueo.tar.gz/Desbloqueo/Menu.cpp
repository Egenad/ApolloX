/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Menu.cpp
 * Author: shiro
 * 
 * Created on 26 de marzo de 2018, 14:42
 */

#include "Menu.h"
#include <SFML/Graphics.hpp>

Menu::Menu() {
    
    seleccionado=0;
    
    if(!fuente.loadFromFile("resources/Loma.ttf")){
        //handle error
    }
    seleccionadores=new sf::Text[3];
    
    seleccionadores[0].setFont(fuente);
    seleccionadores[0].setColor(sf::Color::Cyan);
    seleccionadores[0].setString("Mision 1");
    seleccionadores[0].setPosition(sf::Vector2f(0,0));
    
    seleccionadores[1].setFont(fuente);
    seleccionadores[1].setColor(sf::Color::Red);
    seleccionadores[1].setString("Mision 2");
    seleccionadores[1].setPosition(sf::Vector2f(0,35));
    
    seleccionadores[2].setFont(fuente);
    seleccionadores[2].setColor(sf::Color::Red);
    seleccionadores[2].setString("Mision 3");
    seleccionadores[2].setPosition(sf::Vector2f(0,70));
}

Menu::Menu(const Menu& orig) {
}

Menu::~Menu() {
}

void Menu::draw(sf::RenderWindow& window){
    for(int i=0;i<3;i++){
        window.draw(seleccionadores[i]);
    }
    
}

void Menu::moveUp(){
    if(seleccionado!=0){
        seleccionadores[seleccionado].setColor(sf::Color::Red);
        seleccionado--;
        seleccionadores[seleccionado].setColor(sf::Color::Cyan);
    }
}

void Menu::moveDown(){

    if(seleccionado!=2){
        seleccionadores[seleccionado].setColor(sf::Color::Red);
        seleccionado++;
        seleccionadores[seleccionado].setColor(sf::Color::Cyan);
    }
}

int Menu::getSeleccionado(){
    
    return seleccionado;
}


