/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: angel
 *
 * Created on 21 de marzo de 2018, 11:18
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include "nave.h"
#include "Nivel.h"
#define kVel 7


int main()
{
    //Creamos una ventana
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");

    nave player;
    sf::Clock clock;
    Nivel nivel;
    int contador = 0;
    
    //Bucle del juego
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {  
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
                if(player.getX()>30){
                    player.move(sf::Vector2f(-kVel,0)); 
                }
                if(player.getY()>20 && nivel.getJefe()){
                    player.move(sf::Vector2f(0,-kVel)); 
                }    
            }
            else{
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
                    if(player.getX()>30){
                        player.move(sf::Vector2f(-kVel,0)); 
                    }
                    if(player.getY() < 850 && nivel.getJefe()){
                        player.move(sf::Vector2f(0,kVel)); 
                    }
                }
                else{
                    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
                        if(player.getX()<620){
                            player.move(sf::Vector2f(kVel,0));
                        }
                        if(player.getY() < 850 && nivel.getJefe()){
                            player.move(sf::Vector2f(0,kVel)); 
                        }
                    }
                    else{
                        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
                            if(player.getX()<620){
                                player.move(sf::Vector2f(kVel,0));
                            }
                            if(player.getY()>20 && nivel.getJefe()){
                                player.move(sf::Vector2f(0,-kVel)); 
                            }
                        }
                        else{
                            
                            switch(event.type){
                
                                //Si se recibe el evento de cerrar la ventana la cierro
                                case sf::Event::Closed:
                                    window.close();
                                    break;

                                //Se pulsó una tecla, imprimo su codigo
                                case sf::Event::KeyPressed:

                                    //Verifico si se pulsa alguna tecla de movimiento
                                    switch(event.key.code) {

                                        //Mapeo del cursor
                                        case sf::Keyboard::Right:

                                            if(player.getX()<620){
                                                player.move(sf::Vector2f(kVel,0));
                                            }

                                        break;

                                        case sf::Keyboard::Left:
                                            if(player.getX()>30){
                                                player.move(sf::Vector2f(-kVel,0)); 
                                            }

                                        break;

                                        case sf::Keyboard::Up:
                                            if(player.getY()>20 && nivel.getJefe()){
                                                player.move(sf::Vector2f(0,-kVel)); 
                                            }

                                        break;

                                        case sf::Keyboard::Down:
                                            if(player.getY() < 850 && nivel.getJefe()){
                                                player.move(sf::Vector2f(0,kVel)); 
                                            }

                                        break;

                                        //Tecla Q para salir
                                        case 16:
                                            window.close();
                                        break;


                                        //Cualquier tecla desconocida se imprime por pantalla su código
                                        default:
                                            std::cout << event.key.code << std::endl;
                                        break;

                                    }
                            }        
                        }
                    }
                }
            }
            
            
            
        }
        
        if(nivel.getlong() <= clock.getElapsedTime().asSeconds()){
            nivel.setJefe(true);
            std::cout << "Cambio a modo jefe" << std::endl;
        }
        
        window.clear();
        player.draw(window);
        window.display();

    }

    return 0;
}