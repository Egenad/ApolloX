/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nivel.cpp
 * Author: angel
 * 
 * Created on 25 de marzo de 2018, 18:12
 */

#include "Nivel.h"

Nivel::Nivel() {
    longitud_camino = 3.0f;
    jefe = false;
}

Nivel::Nivel(const Nivel& orig) {
}

Nivel::~Nivel() {
}

float Nivel::getlong(){
    return longitud_camino;
}

void Nivel::setJefe(bool n){
    jefe = n;
}

bool Nivel::getJefe(){
    return jefe;
}

