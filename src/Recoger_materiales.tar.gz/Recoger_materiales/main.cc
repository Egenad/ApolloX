#include <iostream>
#include <SFML/Graphics.hpp>
#include "Nave.h"
#include "Material.h"

#define salto 17

int main()
{
    //Ventana 
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");

    
    /*Crear nave*/
    sf::Texture tex_nave;
    if (!tex_nave.loadFromFile("resources/spritesheet.png"))
    {
        std::cerr << "Error cargando la imagen spritessheet.png";
        exit(0);
    }

    sf::Sprite s_nave(tex_nave);
    s_nave.setOrigin(110/2,400/2);
    s_nave.setTextureRect(sf::IntRect(0, 0, 110, 400));
    s_nave.scale(0.5, 0.5);
    
    sf::Sprite s_nave_esc(tex_nave);
    s_nave_esc.setOrigin(110/2,400/2);
    s_nave_esc.setTextureRect(sf::IntRect(2*110+2, 0, 110, 400));
    s_nave_esc.scale(0.5, 0.5);
    
    Nave nave(320, 800, s_nave);
    
     /*Crear alien, obstaculo, escudo y material*/
    //Sprite enemigo
    
    //Cargar imagen textura
    
    sf::Texture tex;
    if (!tex.loadFromFile("resources/sprites.png"))
    {
        std::cerr << "Error cargando la imagen enemigo.png";
        exit(0);
    }
    
    
    sf::Sprite block(tex);
    block.setOrigin(32/2,32/2);
    block.setTextureRect(sf::IntRect(0*32, 5*32, 32, 32));
    
    Material material1(150, 200, block,0);
    
    
    block.setTextureRect(sf::IntRect(2*32+16, 5*32, 32, 32));
    
    Material material2(250, 200, block,1);
    
    
    block.setTextureRect(sf::IntRect(5*32, 5*32, 32, 32));
    
    Material material3(350, 200, block,2);
    
    
    block.setTextureRect(sf::IntRect(7*32+16, 5*32, 32, 32));
    
    Material material4(450, 200, block,3);
    
    /*Inicializar clock*/
    sf::Clock clock;
    bool mov=false;
    
    //Bucle del juego
    while (window.isOpen())
    {
        //Movimiento objetos
        if (clock.getElapsedTime().asSeconds() > 0.1f && mov==true){
             
            material1.move();
            material2.move();
            material3.move();
            material4.move();
    
            clock.restart();
        }
        
        //Colision con algun objeto
        
        if(nave.get_posx() > (material1.get_posx()-25) && nave.get_posx() < (material1.get_posx()+25)){
            if(material1.get_posy()>nave.get_posy()-100 && material1.get_posy()<nave.get_posy()){
                if(material1.get_estado()==1){
                    material1.set_estado(0);  
                    nave.coger_material(material1.get_tipo());
                    std::cout << "Ha recogido material tipo: " << material1.get_tipo() << std::endl;
               }
            }    
        }else if(nave.get_posx() > (material2.get_posx()-25) && nave.get_posx() < (material2.get_posx()+25)){
            if(material2.get_posy()>nave.get_posy()-100 && material2.get_posy()<nave.get_posy()){
               if(material2.get_estado()==1){
                    material2.set_estado(0);  
                    nave.coger_material(material2.get_tipo());
                    std::cout << "Ha recogido material tipo: " << material2.get_tipo() << std::endl;
               }
            }    
        }else if(nave.get_posx() > (material3.get_posx()-25) && nave.get_posx() < (material3.get_posx()+25)){
            if(material3.get_posy()>nave.get_posy()-100 && material3.get_posy()<nave.get_posy()){
               if(material3.get_estado()==1){
                    material3.set_estado(0); 
                    nave.coger_material(material3.get_tipo());
                    std::cout << "Ha recogido material tipo: " << material3.get_tipo() << std::endl;
               }
            }    
        }else if(nave.get_posx() > (material4.get_posx()-25) && nave.get_posx() < (material4.get_posx()+25)){
            if(material4.get_posy()>nave.get_posy()-100 && material4.get_posy()<nave.get_posy()){
                if(material4.get_estado()==1){
                    material4.set_estado(0);
                    nave.coger_material(material4.get_tipo());
                    std::cout << "Ha recogido material tipo: " << material4.get_tipo() << std::endl;
                }
            }    
        }
        
        
         
       
        //Bucle de obtención de eventos
        sf::Event event;
        while (window.pollEvent(event))
        {
            
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                //Se pulsó una tecla, imprimo su codigo
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        //Mapeo del cursor
                        case sf::Keyboard::Right:
                            nave.move(salto,0);
                        break;

                        case sf::Keyboard::Left:
                            nave.move(-salto,0); 
                        break;
                        
                        case 57:
                            //movimiento de los objetos
                            if(mov==true){
                                mov=false;
                            }else{
                                mov=true;
                            }
                            
                        break;
                        
                        case 0:
                            std::cout << "Total materiales"<< std::endl;
                            std::cout << "Carbon: " << nave.get_total_carbon() << std::endl;
                            std::cout << "Hierro: " << nave.get_total_hierro() << std::endl;
                            std::cout << "Titanio: " << nave.get_total_titanio() << std::endl;
                            std::cout << "Magnesio: " << nave.get_total_magnesio() << std::endl;
                        break;
                            
                        //Tecla ESC para salir
                        case sf::Keyboard::Escape:
                            window.close();
                        break;
                        
                        //Cualquier tecla desconocida se imprime por pantalla su código
                        default:
                            std::cout << event.key.code << std::endl;
                        break;
                              
                    }

            }
            
        }

        window.clear();
        if(material1.get_estado()==1){
            window.draw(material1.get_sprite());
        }
        
        if(material2.get_estado()==1){
            window.draw(material2.get_sprite());
        }
        
        if(material3.get_estado()==1){
            window.draw(material3.get_sprite());
        }
        
        if(material4.get_estado()==1){
            window.draw(material4.get_sprite());
        }
        
        if(nave.get_estado() != 0){
            window.draw(nave.get_sprite());
        }
        
        window.display();
    }

    return 0;
}