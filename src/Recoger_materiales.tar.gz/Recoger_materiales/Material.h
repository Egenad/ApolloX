/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Material.h
 * Author: raquel
 *
 * Created on 23 de marzo de 2018, 11:40
 */
#include <iostream>
#include <SFML/Graphics.hpp>

#ifndef MATERIAL_H
#define MATERIAL_H

class Material {
public:
    Material();
    Material (int, int, sf::Sprite,int);
    void set_sprite(sf::Sprite);
    void set_estado(int);
    int get_posx();
    int get_posy();
    sf::Sprite get_sprite();
    int get_estado();
    int get_tipo();
    void move();
    Material(const Material& orig);
    virtual ~Material();
private:
    int tipo; // 0-carbon, 1-hierro, 2-titanio, 3-magnesio
    int pos_x;
    int pos_y;
    sf::Sprite sprite;
    int estado; //0-ya ha sido cogido , 1-no se ha cogido

};

#endif /* MATERIAL_H */

