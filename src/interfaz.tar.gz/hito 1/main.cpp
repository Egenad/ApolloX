#include <iostream>
#include <SFML/Graphics.hpp>
#include "Menu.h"

int main() {

    //Creamos una ventana
    sf::RenderWindow window(sf::VideoMode(640, 880), "menus");

    Menu menu [7]={{0},{1},{2},{3},{4},{5},{6}}; //dios esto es super util
    int cualMenu=0;
    int last=-1;
    
    while (window.isOpen())
    {
       sf::Event event;
        while (window.pollEvent(event))
        {      
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        //Mapeo del cursor
                        case sf::Keyboard::Up:
                            
                            menu[cualMenu].moveUp();
                                        
                        break;

                        case sf::Keyboard::Down:
                            menu[cualMenu].moveDown(cualMenu);
                            
                        break;
                        
                        case 4:
                            if(cualMenu==4||cualMenu==2){
                                if(cualMenu==4){
                                    last=0;
                                }else if(cualMenu==2){
                                    last=1;
                                }
                                cualMenu=5;
                            }
                        break;
                        
                        case 23:
                            if(cualMenu==4||cualMenu==2){
                                if(cualMenu==4){
                                    last=0;
                                }else if(cualMenu==2){
                                    last=1;
                                }
                                cualMenu=6;
                            }
                        break;

                        case sf::Keyboard::Return:
                            switch(menu[cualMenu].getSeleccionado()){
                            
                                case 0:
                                    
                                    if(cualMenu==0){
                                        cualMenu=1; //vamos a la seleccion de niveles
                                    }else if(cualMenu==1){
                                        cualMenu=4; //vamos a la mision
                                        std::cout << "Estas en el modo infinito, pulsa E para abrir el menu de pausa y X para terminar la partida." << std::endl;

                                    }else if(cualMenu==5||cualMenu==6){ //pausa
                                        if(last==1){
                                            cualMenu=2; //retomamos modo infinito
                                        }else if(last==0){
                                            cualMenu=4; //retomamos mision
                                        }
                                    }

                                break;
                                
                                case 1:
                                    if(cualMenu==0){
                                        cualMenu=2; //vamos al modo infinito
                                        std::cout << "Estas en el modo infinito, pulsa E para abrir el menu de pausa y X para terminar la partida." << std::endl;

                                    }else if(cualMenu==1){
                                        cualMenu=4; //vamos a la mision
                                        std::cout << "Estas en la mision, pulsa E para abrir el menu de pausa y X para terminar la partida." << std::endl;
                                    }else if(cualMenu==5){
                                        if(last==1){
                                            cualMenu=0;
                                        }else if(last==0){
                                            cualMenu=1;
                                        }
                                    }else if(cualMenu==6){
                                        if(last==1){
                                            cualMenu=0;
                                        }else if(last==0){
                                            cualMenu=1;
                                        }
                                    }
                                  
                                break;
                                
                                case 2:
                                    //base
                                    if(cualMenu==0){
                                        cualMenu=3; //vamos a la tienda
                                    }else if(cualMenu==1){
                                        cualMenu=4;
                                        std::cout << "Estas en el modo infinito, pulsa E para abrir el menu de pausa y X para terminar la partida." << std::endl;

                                    }
                                    
                                break;
                                
                                case 3:
                                    
                                    if(cualMenu==0){
                                        window.close();
                                    }else if(cualMenu==1||cualMenu==3){
                                        cualMenu=0;
                                    }
                                break;
                            }
                            
                        break;
                        
                    }
            }
        }

        window.clear();
        menu[cualMenu].draw(window,cualMenu);
        window.display();
        
    }
    
    return 0;
}

