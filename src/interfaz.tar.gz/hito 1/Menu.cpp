/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Menu.cpp
 * Author: shiro
 * 
 * Created on 23 de marzo de 2018, 12:16
 */

#include "Menu.h"

Menu::Menu(int tipo) {
    if(!fuente.loadFromFile("resources/Loma.ttf")){
        //handle error
    }
    
    switch(tipo){
        
        
        case 0: //menu principal (4 opciones)
            seleccionadores=new sf::Text[4];


            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Modo Historia");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            seleccionadores[1].setFont(fuente);
            seleccionadores[1].setColor(sf::Color::Red);
            seleccionadores[1].setString("Modo Infinito");
            seleccionadores[1].setPosition(sf::Vector2f(0,35));

            seleccionadores[2].setFont(fuente);
            seleccionadores[2].setColor(sf::Color::Red);
            seleccionadores[2].setString("Base");
            seleccionadores[2].setPosition(sf::Vector2f(0,70));

            seleccionadores[3].setFont(fuente);
            seleccionadores[3].setColor(sf::Color::Red);
            seleccionadores[3].setString("Salir");
            seleccionadores[3].setPosition(sf::Vector2f(0,105));
        break;
        
        case 1: //modo historia (4 opciones)
            seleccionadores=new sf::Text[4];


            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Mision 1");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            seleccionadores[1].setFont(fuente);
            seleccionadores[1].setColor(sf::Color::Red);
            seleccionadores[1].setString("Mision 2");
            seleccionadores[1].setPosition(sf::Vector2f(0,35));

            seleccionadores[2].setFont(fuente);
            seleccionadores[2].setColor(sf::Color::Red);
            seleccionadores[2].setString("Mision 3");
            seleccionadores[2].setPosition(sf::Vector2f(0,70));
            
            seleccionadores[3].setFont(fuente);
            seleccionadores[3].setColor(sf::Color::Red);
            seleccionadores[3].setString("Atras");
            seleccionadores[3].setPosition(sf::Vector2f(0,105));
            
        break;
        
        case 2: //modo infinito NADA
            seleccionadores=new sf::Text[1];


            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Modo infinito");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            
        break;
        
        case 3: //tienda (4 opcions)
            seleccionadores=new sf::Text[4];
            
            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Personalizar nave");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            seleccionadores[1].setFont(fuente);
            seleccionadores[1].setColor(sf::Color::Red);
            seleccionadores[1].setString("Flota");
            seleccionadores[1].setPosition(sf::Vector2f(0,35));

            seleccionadores[2].setFont(fuente);
            seleccionadores[2].setColor(sf::Color::Red);
            seleccionadores[2].setString("Reparar");
            seleccionadores[2].setPosition(sf::Vector2f(0,70));

            seleccionadores[3].setFont(fuente);
            seleccionadores[3].setColor(sf::Color::Red);
            seleccionadores[3].setString("Atras");
            seleccionadores[3].setPosition(sf::Vector2f(0,105));
            
        break;
        
        case 4: //modo historia NADA
            seleccionadores=new sf::Text[1];
            
            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Mision");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));
            
        break;
        
        case 5: //pausa (2 opciones
            seleccionadores=new sf::Text[2];
            
            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Reanudar");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            seleccionadores[1].setFont(fuente);
            seleccionadores[1].setColor(sf::Color::Red);
            seleccionadores[1].setString("Salir");
            seleccionadores[1].setPosition(sf::Vector2f(0,35));
            
        break;
        
        case 6: //resultados (2 opciones
            seleccionadores=new sf::Text[2];
            
            seleccionadores[0].setFont(fuente);
            seleccionadores[0].setColor(sf::Color::Cyan);
            seleccionadores[0].setString("Reintentar");
            seleccionadores[0].setPosition(sf::Vector2f(0,0));

            seleccionadores[1].setFont(fuente);
            seleccionadores[1].setColor(sf::Color::Red);
            seleccionadores[1].setString("Salir");
            seleccionadores[1].setPosition(sf::Vector2f(0,35));
            
        break;
    }
    
    seleccionado=0;
    
}

Menu::Menu(const Menu& orig) {
}

Menu::~Menu() {
}

void Menu::draw(sf::RenderWindow& window,int tipo){
    
    int cont;
    if(tipo==3||tipo==1||tipo==0){
        cont=4;
    }else if(tipo==4||tipo==2){
        cont=1;
    }else{
        cont=2;
    }
    
    for(int i=0;i<cont;i++){
        window.draw(seleccionadores[i]);
    }
    
}

void Menu::moveUp(){
    
    
    
    if(seleccionado!=0){
        seleccionadores[seleccionado].setColor(sf::Color::Red);
        seleccionado--;
        seleccionadores[seleccionado].setColor(sf::Color::Cyan);
    }
}

void Menu::moveDown(int tipo){
    int cont;
    
    if(tipo==3||tipo==1||tipo==0){
        cont=3;
    }else if(tipo==4||tipo==2){
        cont=0;
    }else{
        cont=1;
    }
    
    if(seleccionado!=cont){
        seleccionadores[seleccionado].setColor(sf::Color::Red);
        seleccionado++;
        seleccionadores[seleccionado].setColor(sf::Color::Cyan);
    }
}

int Menu::getSeleccionado(){
    
    return seleccionado;
}
