/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Magnesio.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:36
 */

#ifndef MAGNESIO_H
#define MAGNESIO_H

class Magnesio {
public:
    Magnesio();
    Magnesio(const Magnesio& orig);
    virtual ~Magnesio();
private:

};

#endif /* MAGNESIO_H */

