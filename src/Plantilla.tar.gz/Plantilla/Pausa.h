/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pausa.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:31
 */

/*** SINGLETON */

#ifndef PAUSA_H
#define PAUSA_H

class Pausa {
public:
    Pausa();
    Pausa(const Pausa& orig);
    virtual ~Pausa();
private:

};

#endif /* PAUSA_H */

