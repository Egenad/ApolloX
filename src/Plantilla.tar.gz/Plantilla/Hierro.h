/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Hierro.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:35
 */

#ifndef HIERRO_H
#define HIERRO_H

class Hierro {
public:
    Hierro();
    Hierro(const Hierro& orig);
    virtual ~Hierro();
private:

};

#endif /* HIERRO_H */

