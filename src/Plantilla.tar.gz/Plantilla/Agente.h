/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Agente.h
 * Author: raquel
 *
 * Created on 26 de marzo de 2018, 21:33
 */

#ifndef AGENTE_H
#define AGENTE_H

class Agente {
public:
    Agente();
    Agente(const Agente& orig);
    virtual ~Agente();
private:

};

#endif /* AGENTE_H */

