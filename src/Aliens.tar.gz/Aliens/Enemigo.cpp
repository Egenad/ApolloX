/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Enemigo.cpp
 * Author: jose
 * 
 * Created on 24 de marzo de 2018, 19:46
 */

#include "Enemigo.hpp"
#include <math.h>

Enemigo::Enemigo(sf::Vector2f size, int tip) {
    tipo=tip; //tipo de movimiento
    alien.setSize(size); //tamaño
    alien.setFillColor(sf::Color::Red); //color
    
    pos.x=rand()%(600-100);
    pos.y=-50;
    alien.setPosition(pos);
    

}

void Enemigo::setPos(int x, int y){
    alien.setPosition(x,y);
}
 int Enemigo::getX(){
     return alien.getPosition().x;
}
 int Enemigo::getY(){
     return alien.getPosition().y;
        
}
void Enemigo::draw(sf::RenderWindow &window){
    window.draw(alien);
}

sf::RectangleShape& Enemigo::getShape(){
    return alien;
}

sf::Vector2f Enemigo::getPos(){
    return pos;
}

void Enemigo::dispara(){
    if(dis.getElapsedTime().asSeconds()>1){
        Bullet *newBullet= new Bullet(sf::Vector2f(5,20));//TAMAÑO DE BALA
        newBullet->setPos(sf::Vector2f(alien.getPosition().x+20,alien.getPosition().y));//POSICION DE LA BALA
        balas.push_back(newBullet);//VECTOR DE BALAS
        dis.restart();
    }

}

void Enemigo::dibujaBalas(sf::RenderWindow &window, Nave &nave){
        for(int n=0; n< balas.size(); n++){//DIBUJAMOS LAS BALAS      
            balas[n]->draw(window);
            balas[n]->fire(6);//LE PASAMOS LA VELOCIDAD DE DISPARO
        }
        
        for(int k=0;k< balas.size();k++){
            bool cola=false;
            cola=nave.checkColl(*balas[k]); //LE PASAMOS LA BALA CON LA QUE COLOSIONA
            if(cola){
                delete balas[k];
                balas.erase(balas.begin()+k);
                
            }
        }
}

void Enemigo::mov(float grados){
    alien.move(sin(grados),1);

}

int Enemigo::getTipo(){
    return tipo;
}



