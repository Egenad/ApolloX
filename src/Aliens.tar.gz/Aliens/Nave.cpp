/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nave.cpp
 * Author: jose
 * 
 * Created on 24 de marzo de 2018, 19:45
 */

#include "Nave.hpp"

Nave::Nave(sf::Vector2f size) {
    
    nave.setSize(size);
    nave.setFillColor(sf::Color::Blue);
    nave.setOutlineColor(sf::Color::Green);
    vida=1000;
    
}

void Nave::move(sf::Vector2f dir){
    nave.move(dir);
}

int Nave::getX(){
    return nave.getPosition().x;

}


int Nave::getY(){
    return nave.getPosition().y;
}

int Nave::getVida(){
    return vida;
}

void Nave::setPos(sf::Vector2f newPos){
    nave.setPosition(newPos);
}

bool Nave::checkColl(Bullet &bullet){//COLISIONES
   // if(bullet.getLeft() > nave.getPosition().x && bullet.getRight() > nave.getPosition().x && bullet.getTop() < nave.getPosition().y + nave.getSize().y && bullet.getBottom() > nave.getPosition().y){
        //ESTAMOS COLISIONANDO 100%
    bool cola=false;
    if(nave.getGlobalBounds().intersects(bullet.returnShape().getGlobalBounds())){ 
        //detectar lo de la vida
        cola=true;
        vida = vida - 225;
        if(vida<=0){
           nave.setPosition(sf::Vector2f(10000,10000));
        }
    }
    
    return cola;
}

void Nave::draw(sf::RenderWindow &window){
    window.draw(nave);
}



