
#include "Enemigo.hpp"
#include "Bullet.hpp"
#include "Nave.hpp"
#include <SFML/Graphics.hpp>
#include <list>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>


int main()
{
    //SEMILLA PARA LOS RAND
    srand(time(NULL));
    const int sizei=3;
    const int sizej=3;
    int i=0;

    //VECTOR ENEMIGOS
    std::vector<Enemigo*> alo;
    
    //CREAMOS VENTANA
    sf::RenderWindow window(sf::VideoMode(640, 480), "Aliens!");
    window.setVerticalSyncEnabled(true);
    
    //RELOJ PARA SINCRONIZAR LOS FRAMES
    sf::Clock synchronice_timer;
    sf::Clock apa;
    sf::Clock res;
    
    //Definimos las clases
    Nave nave(sf::Vector2f(50, 50));
    
    nave.setPos(sf::Vector2f(320, 400));
    
    
    //---------variables setting---------------
    bool isFiring=false;
    float grados=90.0f;//movimiento del alien
    float grados1=180.0f;
    float grados2=135.0f;
    
    //-----------------
    
    
    
    //Bucle principal
    while(window.isOpen())
    {   
        
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            
            int ms = 10;
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
                nave.move(sf::Vector2f(-ms,0));
            }
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
                nave.move(sf::Vector2f(ms,0));
            }
            
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
                nave.move(sf::Vector2f(-ms,0));
            }
            
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
                nave.move(sf::Vector2f(ms,0));
            }
                         
        }
        
    if(res.getElapsedTime().asSeconds()>4){
        //if(i<4){ Para controlar cuanto aliens salen en este caso infinito
            int randx=rand()%(600-100);
            int randtipo=rand()%(3-0)+1;
            std::cout<<randtipo <<"\n";
            Enemigo *newEne= new Enemigo(sf::Vector2f(50,50),randtipo);//creamos un enemigo
            alo.push_back(newEne);//VECTOR DE Enemigos
            res.restart();
            
            std::cout<<"dibujo\n";
            i++;
       // }
    }
        
        window.clear();
        
        
        for(int i=0;i<alo.size();i++){ //disparo de los aliens
            alo[i]->dispara();

        }
        
        for(int n=0;n<alo.size();n++){ //dibujamos la balas de los aliens
            alo[n]->dibujaBalas(window,nave);

        }
       
          

        
        
        
        
        //MOSTRAR EN PANTALLA
        nave.draw(window);
        
        for(int n=0;n<alo.size();n++){
                std::cout<<"TIPO: " << alo[n]->getTipo() <<std::endl;
            alo[n]->draw(window);
            if(alo[n]->getTipo()==1){
                alo[n]->mov(grados);
                grados=grados+0.006f;
            }
            else if(alo[n]->getTipo()==2){
                alo[n]->mov(grados1);
                grados1=grados1+0.006f;
            }
            else if(alo[n]->getTipo()==3){
                alo[n]->mov(grados2);
                grados2=grados2+0.006f;
            }
        }

           
        window.display();
        
        
        
        //SINCRONIZAMOS 30 fps
        while(synchronice_timer.getElapsedTime().asSeconds()<1.0f/30.0f)
        {
            sf::sleep(sf::seconds(1.0f/60.0f));
        }

    }

    return 0;
}