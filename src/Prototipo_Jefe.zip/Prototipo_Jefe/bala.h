/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bala.h
 * Author: angel
 *
 * Created on 21 de marzo de 2018, 11:19
 */

#ifndef BALA_H
#define BALA_H
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

class bala {
   
public:
    bala(sf::Vector2f, int, float, float);
    bala(const bala& orig);
    virtual ~bala();
    void disparar_angulo();
    void draw(sf::RenderWindow&);
    void nuevaPosicion(sf::Vector2f);
    int getX();
    int getY();
    int getTipo();
protected:
    sf::RectangleShape bullet;
    int tipo_bala;
    float angulo;
    float velocidad;
};

#endif /* BALA_H */

