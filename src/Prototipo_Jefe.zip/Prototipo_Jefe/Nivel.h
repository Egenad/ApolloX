/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nivel.h
 * Author: angel
 *
 * Created on 25 de marzo de 2018, 18:12
 */

#ifndef NIVEL_H
#define NIVEL_H
#include "Jefe.h"
#include <SFML/Graphics.hpp>
#include <vector>
#include "bala.h"
class Nivel {
public:
    Nivel(int);
    Nivel(const Nivel& orig);
    virtual ~Nivel();
    bool getJefe();
    bool getCreado();
    void setJefe(bool);
    float getlong();
    void crearJefe();
    void update();
    void draw(sf::RenderWindow&);
    std::string getJefeSprite();
    void atacaJefe(sf::Sprite&, std::vector<bala*>&, sf::Sprite&);
private:
    int numero_nivel;
    float longitud_camino;
    bool jefe;
    bool creado;
    Jefe * boss;
};

#endif /* NIVEL_H */

