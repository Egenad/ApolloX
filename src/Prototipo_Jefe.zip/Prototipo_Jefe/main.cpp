/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: angel
 *
 * Created on 21 de marzo de 2018, 11:18
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include "nave.h"
#include "Nivel.h"
#include "bala.h"
#define kVel 7


int main()
{
    //Creamos una ventana
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");
    
    std::vector<bala*> balas_jefe;
    
    nave player;
    sf::Clock clock;
    sf::Clock clock2;
    sf::Clock primer_ataque;
    Nivel nivel(1);
    int contador = 0;
    bool hablar = false;
    bool atacar = true;
    sf::Texture tex;
    sf::Sprite jefe;
    sf::Font font;
    sf::Text punt;
    if (font.loadFromFile("ArcadeClassic.ttf"))
    {   
        punt.setFont(font);
        punt.setString("Lokoooo  te  rajo!");
        punt.setCharacterSize(30);
        punt.setPosition(200,250);
    }

    //Bucle del juego
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {  
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && atacar){
                if(player.getX()>30){
                    player.move(sf::Vector2f(-kVel,0)); 
                }
                if(player.getY()>20 && nivel.getJefe()){
                    player.move(sf::Vector2f(0,-kVel)); 
                }    
            }
            else{
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && atacar){
                    if(player.getX()>30){
                        player.move(sf::Vector2f(-kVel,0)); 
                    }
                    if(player.getY() < 850 && nivel.getJefe()){
                        player.move(sf::Vector2f(0,kVel)); 
                    }
                }
                else{
                    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && atacar){
                        if(player.getX()<620){
                            player.move(sf::Vector2f(kVel,0));
                        }
                        if(player.getY() < 850 && nivel.getJefe()){
                            player.move(sf::Vector2f(0,kVel)); 
                        }
                    }
                    else{
                        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && atacar){
                            if(player.getX()<620){
                                player.move(sf::Vector2f(kVel,0));
                            }
                            if(player.getY()>20 && nivel.getJefe()){
                                player.move(sf::Vector2f(0,-kVel)); 
                            }
                        }
                        else{
                            
                            switch(event.type){
                
                                //Si se recibe el evento de cerrar la ventana la cierro
                                case sf::Event::Closed:
                                    window.close();
                                    break;

                                //Se pulsó una tecla, imprimo su codigo
                                case sf::Event::KeyPressed:

                                    //Verifico si se pulsa alguna tecla de movimiento
                                    switch(event.key.code) {

                                        //Mapeo del cursor
                                        case sf::Keyboard::Right:

                                            if(player.getX()<620 && atacar){
                                                player.move(sf::Vector2f(kVel,0));
                                            }

                                        break;

                                        case sf::Keyboard::Left:
                                            if(player.getX()>30 && atacar){
                                                player.move(sf::Vector2f(-kVel,0)); 
                                            }

                                        break;

                                        case sf::Keyboard::Up:
                                            if(player.getY()>20 && nivel.getJefe() && atacar){
                                                player.move(sf::Vector2f(0,-kVel)); 
                                            }

                                        break;

                                        case sf::Keyboard::Down:
                                            if(player.getY() < 850 && nivel.getJefe() && atacar){
                                                player.move(sf::Vector2f(0,kVel)); 
                                            }

                                        break;

                                        //Tecla Q para salir
                                        case 16:
                                            window.close();
                                        break;


                                        //Cualquier tecla desconocida se imprime por pantalla su código
                                        default:
                                            std::cout << event.key.code << std::endl;
                                        break;

                                    }
                            }        
                        }
                    }
                }
            }   
        }
        
        if(nivel.getJefe()){
            if(!nivel.getCreado()){
                nivel.crearJefe();
                if (!tex.loadFromFile(nivel.getJefeSprite()))
                {
                    std::cerr << "Error cargando la imagen de jefe";
                    exit(0);
                }

                //Cargamos el jefe

                jefe.setTexture(tex);
                jefe.setOrigin(189/2,147/2);    
                jefe.setTextureRect(sf::IntRect(0,0, 189, 147));
                jefe.scale(0.5f, 0.5f);
                jefe.setPosition(320, 0);
              
            }
            else{
                if(jefe.getPosition().y<=200){
                    if(player.getX() > 320){
                        player.move(sf::Vector2f(-0.1,0));
                    }
                    else{
                        if(player.getX() < 320){
                            player.move(sf::Vector2f(0.1,0));
                        }
                    }
                    atacar = false;
                    jefe.move(0,0.05);
                    clock.restart();
                }
                else{
                    if(clock.getElapsedTime().asSeconds() < 2){
                        hablar = true;
                    }
                    else{
                        hablar = false;
                        atacar = true;
                        if(primer_ataque.getElapsedTime().asSeconds() > 1.5f){
                            //crear balas dependiendo de la fase
                            nivel.atacaJefe(jefe, balas_jefe, player.getShiprite());
                            primer_ataque.restart();
                        }
                    }
                }
            }
        }
        else{  
            if(nivel.getlong() <= clock.getElapsedTime().asSeconds()){
                nivel.setJefe(true);
                contador++;
                std::cout << contador << " segundos" << std::endl;
                std::cout << "Cambio a modo jefe" << std::endl;
            }
            else{
                if(clock2.getElapsedTime().asSeconds() >= 1 && !nivel.getJefe()){
                    clock2.restart();
                    contador++;
                    std::cout << contador <<" segundos" << std::endl;
                }
            }
        }
        
        window.clear();
        
        if(nivel.getJefe()){
           
            if(hablar){
                window.draw(punt);
            }
            else{
                if(!balas_jefe.empty()){
                    for(int i=0; i<balas_jefe.size(); i++){
                        balas_jefe[i]->draw(window);
                        balas_jefe[i]->disparar_angulo();
                        if(balas_jefe[i]->getY() < -100 || balas_jefe[i]->getY() > 900 || balas_jefe[i]->getX() < -10 || balas_jefe[i]->getX() > 700){
                            delete balas_jefe[i];
                            balas_jefe.erase(balas_jefe.begin() + i);
                            // std::cout << "Eliminado" << std::endl;
                        }
                    }
                }
            }
            window.draw(jefe);
        }
        
        player.draw(window);
        
        window.display();

    }

    return 0;
}