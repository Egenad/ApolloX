/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Jefe.cpp
 * Author: angel
 * 
 * Created on 26 de marzo de 2018, 12:19
 */

#include "Jefe.h"
#include <iostream>
#include <SFML/Graphics.hpp>
Jefe::Jefe(int n) {
    numero_jefe = n;
    switch(n){
        case 1:
            vida = 10000;
            texture = "jefe1.png";
        break;
        case 2:
            vida = 50000;
        break;
        case 3:
            vida = 100000;
        break;
    }
    fase = 0; 
}

Jefe::Jefe(const Jefe& orig) {
}

Jefe::~Jefe() {
}

void Jefe::danyo(int n){
    vida -= n;
}

int Jefe::getvida(){
    return vida;
}

void Jefe::setFase(){
    switch(numero_jefe){
        case 1:
            if(vida <= 10000 && vida >= 6666 ){
                fase = 1;
            }
            else{
                if(vida <= 6665 && vida >= 3333){
                    fase = 2;
                }
                else{
                    fase = 3;
                }
            }
        break;
    }
}

int Jefe::getFase(){
    return fase;
}

std::string Jefe::getTextureJefe(){
    return texture;
}

