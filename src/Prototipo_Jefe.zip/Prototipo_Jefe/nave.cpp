/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   nave.cpp
 * Author: angel
 * 
 * Created on 21 de marzo de 2018, 11:26
 */

#include <SFML/Graphics.hpp>
#include "nave.h"
#include <iostream>

nave::nave() {

    if (!tex.loadFromFile("galaga_sprites.png"))
    {
        std::cerr << "Error cargando la imagen galaga_sprites.png";
        exit(0);
    }
    
    //NAVE
  
    sprite.setTexture(tex);
    sprite.setOrigin(10,10);
    sprite.scale(2.5,2.5);
    sprite.setTextureRect(sf::IntRect(30,60, 20, 20));
    sprite.setPosition(320, 810);
    
    velocidad_nave = 7;
    en_movimiento = false;
    municion = 1;
}

nave::nave(const nave& orig) {
}

nave::~nave() {
}

void nave::draw(sf::RenderWindow& window){
    window.draw(sprite);
}

void nave::move(sf::Vector2f direccion){
    sprite.move(direccion);
}

sf::Sprite& nave::getShiprite(){
    return sprite;
}

int nave::getX(){
    return sprite.getPosition().x;
}

int nave::getY(){
    return sprite.getPosition().y;
}

void nave::setMunicion(int n){
    municion = n;
}

int nave::getMunicion(){
    return municion;
}

void nave::setLastMove(sf::Vector2f vector){
    lastmove = vector;
}

sf::Vector2f nave::getLastMove(){
    return lastmove;
}

bool nave::getMoviendo(){
    return en_movimiento;
}

void nave::setMoviendo(bool bolean){
    en_movimiento = bolean;
}

int nave::getVelocidadNave(){
    return velocidad_nave;
}