/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nivel.cpp
 * Author: angel
 * 
 * Created on 25 de marzo de 2018, 18:12
 */
#include <iostream>
#include "Nivel.h"
#include "Jefe.h"
#include "bala.h"
#include <vector>
#include <SFML/Graphics.hpp>
#include <stdio.h>
#include <math.h>

#define PI 3.14159265

Nivel::Nivel(int n) {
    longitud_camino = 3.0f;
    jefe = false;
    numero_nivel = n;
    creado = false;
}

Nivel::Nivel(const Nivel& orig) {
}

Nivel::~Nivel() {
}

void Nivel::crearJefe(){
    boss = new Jefe(numero_nivel);
    creado = true;
}

float Nivel::getlong(){
    return longitud_camino;
}

void Nivel::setJefe(bool n){
    jefe = n;
}

std::string Nivel::getJefeSprite(){
    std::string text = boss->getTextureJefe();
    return text;
}

void Nivel::atacaJefe(sf::Sprite& sprite, std::vector<bala*>& balas_jefe, sf::Sprite& nave){
    boss->setFase();
    switch(boss->getFase()){
        case 1:
            float angul = 60;
            for(int i=0; i<8; i++){
                if(i < 4){
                    bala * bullet = new bala(sf::Vector2f(10,10), 2, angul, 0.1f);
                    bullet->nuevaPosicion(sf::Vector2f(sprite.getPosition().x-5, sprite.getPosition().y-30));
                    balas_jefe.push_back(bullet);
                    angul = angul + 20;
                }
                else{
                    if(i<6){
                        angul = angul - 30;
                        bala * bullet = new bala(sf::Vector2f(7,7), 2, angul, 0.06f);
                        bullet->nuevaPosicion(sf::Vector2f(sprite.getPosition().x-5, sprite.getPosition().y-30));
                        balas_jefe.push_back(bullet);
                        angul = angul - 10;
                    }
                    else{
                        if(i<7){
                            bala * bullet = new bala(sf::Vector2f(10,10), 2, 0, 0.1f);
                            bullet->nuevaPosicion(sf::Vector2f(sprite.getPosition().x-5, sprite.getPosition().y-30));
                            balas_jefe.push_back(bullet);
                        }
                        else{
                            bala * bullet = new bala(sf::Vector2f(10,10), 2, 180, 0.1f);
                            bullet->nuevaPosicion(sf::Vector2f(sprite.getPosition().x-5, sprite.getPosition().y-30));
                            balas_jefe.push_back(bullet);
                        }
                    }
                }
            }
            
            
            float distancia2 = nave.getPosition().y - sprite.getPosition().y;
            float distancia = sqrt(pow((nave.getPosition().x-sprite.getPosition().x),2)+pow((nave.getPosition().y-sprite.getPosition().y),2));
            float result = asin(distancia2/distancia) * 180.0 / PI;
            if(nave.getPosition().x > 320){
                result = (90-result) + 90 ;
            }
            bala * bullet = new bala(sf::Vector2f(20,20), 1, result, 0.3f);
            bullet->nuevaPosicion(sf::Vector2f(sprite.getPosition().x-5, sprite.getPosition().y-30));
            balas_jefe.push_back(bullet);
        break;
    }
    
}

bool Nivel::getCreado(){
    return creado;
}

bool Nivel::getJefe(){
    return jefe;
}

