
#include <SFML/Graphics.hpp>
#include <list>
#include <iostream>
#include <stdlib.h>
#include <time.h>

int main()
{
    
    /*------VARIABLES DE SETTINGS---------------*/
    int sizei=5; //tamaño i de la matriz de meteoritos
    int sizej=5; //tamaño j de la matriz de meteoritos
    int vely=6; //velocidad en y
    int radiomax=80; //radio maximo del meteorito
    int radiomin=15; //radio minimo del meteorito
    /*------------------------------------------*/
    
    srand(time(NULL));
    //MATRIZ DE METEORITOS
    sf::CircleShape rock_shape[sizei][sizej];
    
    //MATRIZ DE TIPOS DEPENDE DE DONDE HACEN RESPAWN LOS METEORITOS
    int tipos[sizei][sizej]; //si es de -20 a 200 TIPO 1
                             //si 200 a 400  TIPO 2
                             //si 400 a 660  TIPO 3
    
    for(int i=0;i<sizei;i++){
        for(int j=0;j<sizej;j++){
            float ran1=rand()%(radiomax-radiomin);  //numero aleatorio para radio del meteorito
            float ranx=rand()%700-60; //numero aleatorio para respawn en eje x
            rock_shape[i][j].setRadius(ran1);
            rock_shape[i][j].setFillColor( sf::Color( 0, 0, 0, 0xFF) );
            rock_shape[i][j].setOutlineColor( sf::Color::White );
            rock_shape[i][j].setOutlineThickness(2);
            rock_shape[i][j].setOrigin(ran1, ran1);
            rock_shape[i][j].setPosition(ranx,-radiomax);
            
            std::cout<<" //"<<rock_shape[i][j].getPosition().x<< "// ";
                    
            //LO Clasificamos en tipos para determinar la trayectoria del meteorito
            if(rock_shape[i][j].getPosition().x<=200){
                tipos[i][j]=1;
                std::cout <<tipos[i][j];
            }
            else if(200<rock_shape[i][j].getPosition().x && rock_shape[i][j].getPosition().x<=400){
                tipos[i][j]=2;
                std::cout <<tipos[i][j];
            }
            
            else if(rock_shape[i][j].getPosition().x>400){
                tipos[i][j]=3;
                std::cout <<tipos[i][j];
            }
            
        }
        std::cout<<std::endl;
    }
    
    
    sf::RenderWindow window(sf::VideoMode(640, 480), "Meteoritos!");
    window.setVerticalSyncEnabled(true);
    
    
    //RELOJ PARA SINCRONIZAR LOS FRAMES
    sf::Clock synchronice_timer;
    sf::Clock apa; //Aparaición de los meteoritos
    
    
    //SHAPE DE LA NAVE
    sf::ConvexShape ship_shape;
    
    ship_shape.setPointCount(3);
    ship_shape.setPoint(0, sf::Vector2f(10.0f, 0.0f));
    ship_shape.setPoint(1, sf::Vector2f(-10.0f, 7.5f));
    ship_shape.setPoint(2, sf::Vector2f(-10.0f, -7.5f));
    
    ship_shape.setFillColor(sf::Color::Blue);
    ship_shape.setOutlineColor(sf::Color::Green);
    ship_shape.setOutlineThickness(2);
    ship_shape.setPosition(320.0f, 440.0f);
    ship_shape.setRotation(270.0f);
    
    //SHAPE METEORITO
    sf::CircleShape shape(100.f);
 
    shape.setRadius( 30.0f);
    shape.setFillColor( sf::Color( 0, 0, 0, 0xFF) );
    shape.setOutlineColor( sf::Color::White );
    shape.setOutlineThickness(2);
    shape.setOrigin( 30.0f, 30.0f );
    shape.setPosition(100,100);
    

    int n=0;
    int k=0;
    
    
    //Bucle principal
    while(window.isOpen())
    {
        
        
        
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            
        }
        
        
        //DIBUJAR 
        window.clear();
        window.draw(ship_shape);
        

        
        for(int t=0;t<sizei;t++){
            for(int m=0;m<sizej;m++){
                window.draw(rock_shape[t][m]);
            }
        }
        
        
        if(apa.getElapsedTime().asSeconds()>0.0005f && n<sizei && k<sizej){
            
            
            //PARA QUE SE EMPIECE A MOVER EL SIGUIENTE
            if(k!=0){
                if(rock_shape[n][k].getPosition().y>=100){
                    if(tipos[n][k+1]==1){ //direccion de la roca x, y
                        rock_shape[n][k+1].move(1,vely);
                    }
                    else if(tipos[n][k+1]==2){
                        rock_shape[n][k+1].move(0,vely);
                        std::cout<<" tipo 2";
                    }
                    else if(tipos[n][k+1]==3){
                        rock_shape[n][k+1].move(-1,vely);
                    }
                    //rock_shape[n][k+1].move(1,1);
                    std::cout<<"me muevo lambo"<< n <<std::endl;
                }
            }
            else if(n!=0){
                if(rock_shape[n][k].getPosition().y>=100){
                    if(tipos[n-1][k]==1){ //direccion de la roca x, y
                        rock_shape[n-1][k].move(1,vely);
                    }
                    else if(tipos[n-1][k]==2){
                        rock_shape[n-1][k].move(0,vely);
                        std::cout<<" tipo 2";
                    }
                    else if(tipos[n-1][k]==3){
                        rock_shape[n-1][k].move(-1,vely);
                    }
                    //rock_shape[n-1][k].move(1,1);
                     std::cout<<"me muevo maquina"<< n <<std::endl;
                }
            }
            
            //CONTROLAMOS LA DIRECCION DEL METEORITO
            if(tipos[n][k]==1){ //direccion de la roca x, y
                rock_shape[n][k].move(1,vely);
            }
            else if(tipos[n][k]==2){
                rock_shape[n][k].move(0,vely);
                std::cout<<" tipo 2";
            }
            else if(tipos[n][k]==3){
                rock_shape[n][k].move(-1,vely);
            }
            
           //rock_shape[n][k].move(1,1);
            
            std::cout<<"soy n: "<< n <<std::endl;
            std::cout<<"soy k: "<< k <<std::endl;
            
            if(rock_shape[n][k].getPosition().y>500+radiomax){//para que salga por abajo de la pantalla
                if(k==sizei-1){
                    n++;
                    k=-1;
                }
            k++;
            }
            apa.restart();
            
        }
        
        //MOSTRAR EN PANTALLA
        window.display();
        
        //SINCRONIZAMOS 30 fps
        while(synchronice_timer.getElapsedTime().asSeconds()<1.0f/30.0f)
        {
            sf::sleep(sf::seconds(1.0f/60.0f));
        }

    }

    return 0;
}