/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   balas.cpp
 * Author: angel
 *
 * Created on 21 de marzo de 2018, 11:18
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
#include "bala.h"
#include "nave.h"
#define kVel 7


int main()
{
    //Creamos una ventana
    sf::RenderWindow window(sf::VideoMode(640, 880), "Apollo X");

    nave player;
    bool disparando = false;
    bool canyon = false;
    std::vector<bala*> vector_balas;
    sf::Clock reloj;
    sf::Clock tiempo_entre_balas;
    int contador = 0;
    bool bomba_viva = false;
    bool explotado = false;
    
    //Bucle del juego
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event)){
            
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Space)){
                if(player.getX()!=20){
                    player.move(sf::Vector2f(-player.getVelocidadNave(),0));
                    player.setLastMove(sf::Vector2f(-player.getVelocidadNave(), 0));
                }
                if(player.getMunicion() != 3){
                    if(player.getMunicion() == 4 && bomba_viva == false){
                        disparando = true;
                        bomba_viva = true;
                        explotado = false;
                    }
                    else{
                        if(player.getMunicion()!=4){
                            if(tiempo_entre_balas.getElapsedTime().asSeconds() >=0.2){
                                disparando = true;
                                tiempo_entre_balas.restart();
                            }
                        }
                    }
                }
                else{
                    for(int i=0; i<vector_balas.size(); i++){
                        if(vector_balas[i]->getTipo() == 3){
                            vector_balas[i]->disparar_canyon(player.getLastMove());
                        }
                    }
                }
            }
            else{
               if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Space)){
                    if(player.getX()!=620){
                        player.move(sf::Vector2f(player.getVelocidadNave(),0));    
                        player.setLastMove(sf::Vector2f(player.getVelocidadNave(), 0));
                    }
                    if(player.getMunicion() != 3){
                        if(player.getMunicion() == 4 && bomba_viva == false){
                            disparando = true;
                            bomba_viva = true;
                            explotado = false;
                        }
                        else{
                            if(player.getMunicion()!=4){
                                if(tiempo_entre_balas.getElapsedTime().asSeconds() >=0.2){
                                    disparando = true;
                                    tiempo_entre_balas.restart();
                                }
                            }
                        }
                    }
                    else{
                        for(int i=0; i<vector_balas.size(); i++){
                            if(vector_balas[i]->getTipo() == 3){
                                vector_balas[i]->disparar_canyon(player.getLastMove());
                            }
                        }
                    }
                }else{
                    switch(event.type){
                
                        //Si se recibe el evento de cerrar la ventana la cierro
                        case sf::Event::Closed:
                            window.close();
                        break;
                    
                        //Se pulsó una tecla, imprimo su codigo
                        case sf::Event::KeyPressed:

                            //Verifico si se pulsa alguna tecla de movimiento
                            switch(event.key.code) {

                                //Mapeo del cursor
                                case sf::Keyboard::Right:

                                    if(player.getX()!=620){
                                        player.move(sf::Vector2f(player.getVelocidadNave(),0));    
                                        player.setLastMove(sf::Vector2f(player.getVelocidadNave(), 0));
                                        player.setMoviendo(true);
                                    }

                                break;

                                case sf::Keyboard::Left:
                                    if(player.getX()!=20){
                                        player.move(sf::Vector2f(-player.getVelocidadNave(),0));
                                        player.setLastMove(sf::Vector2f(-player.getVelocidadNave(), 0));
                                        player.setMoviendo(true);
                                    }

                                break;
                                case 27:
                                    if(player.getMunicion() != 3){
                                        std::cout << "Municion: default" << std::endl;
                                        player.setMunicion(1);
                                    }
                                break;
                                case 28:
                                    if(player.getMunicion() != 3){
                                        std::cout << "Municion: rafaga" << std::endl;
                                        player.setMunicion(2);
                                    }
                                break;
                                case 29:
                                    if(player.getMunicion() != 3){
                                        std::cout << "Municion: canyon laser" << std::endl;
                                        player.setMunicion(3);
                                        canyon = true;
                                    }
                                break;
                                case 30:
                                    if(player.getMunicion() != 3){
                                        std::cout << "Municion: bomba" << std::endl;
                                        player.setMunicion(4);
                                    }
                                break;

                                case 57:
                                    if(player.getMunicion() != 3){
                                        if(player.getMunicion() == 4 && bomba_viva == false){
                                            disparando = true;
                                            bomba_viva = true;
                                            explotado = false;
                                        }
                                        else{
                                            if(player.getMunicion()!=4){
                                                if(tiempo_entre_balas.getElapsedTime().asSeconds() >=0.2){
                                                    disparando = true;
                                                    tiempo_entre_balas.restart();
                                                }
                                            }
                                        }
                                    }
                                break;

                                //Tecla Q para salir
                                case 16:
                                    window.close();
                                break;


                                //Cualquier tecla desconocida se imprime por pantalla su código
                                default:
                                    std::cout << event.key.code << std::endl;
                                break;

                            }
                        }   
                }
            }
        }
           
        window.clear();
        
        if(player.getMunicion() == 3 && canyon){
            bala * bullet = new bala(sf::Vector2f(30, -800),3,3.0f);
            if(!player.getMoviendo()){
                bullet->nuevaPosicion(sf::Vector2f(player.getX()-17, player.getY()-20));
            }
            else{
                if(player.getLastMove().x < 0){
                    bullet->nuevaPosicion(sf::Vector2f(player.getX()-10, player.getY()-20));
                }
                else{
                    bullet->nuevaPosicion(sf::Vector2f(player.getX()-24, player.getY()-20));
                }
            }
            vector_balas.push_back(bullet);
            reloj.restart();
            canyon = false;
        }
        else{
            if(disparando == true){
                if(player.getMunicion() == 1){
                    bala * bullet = new bala(sf::Vector2f(5,50), 1, 2.0f);
                    bullet->nuevaPosicion(sf::Vector2f(player.getX()-5, player.getY()-50));
                    vector_balas.push_back(bullet);
                }else{
                    if(player.getMunicion() == 2){
                        float angul = 60;
                        for(int i=0; i<6; i++){
                            if(i < 4){
                                bala * bullet = new bala(sf::Vector2f(10,10), 2, angul, 2.0f);
                                bullet->nuevaPosicion(sf::Vector2f(player.getX()-5, player.getY()-30));
                                vector_balas.push_back(bullet);
                                angul = angul + 20;
                            }
                            else{
                                angul = angul - 40;
                                bala * bullet = new bala(sf::Vector2f(7,7), 2, angul, 1.0f);
                                bullet->nuevaPosicion(sf::Vector2f(player.getX()-5, player.getY()-30));
                                vector_balas.push_back(bullet);
                                angul = angul + 20;
                            }
                        }
                    }
                    else{
                        if(player.getMunicion() == 4 && bomba_viva == true){
                            bala * bullet = new bala(sf::Vector2f(5,10), 4, 0.7f);
                            bullet->nuevaPosicion(sf::Vector2f(player.getX()-5, player.getY()-50));
                            vector_balas.push_back(bullet);
                            reloj.restart();
                        }
                    }
                }

                disparando = false; 
            }
        }
        
        if(!vector_balas.empty()){
            for(int i=0; i<vector_balas.size(); i++){
                vector_balas[i]->draw(window);
                if(vector_balas[i]->getTipo() == 1){
                    vector_balas[i]->disparar();
                }
                else{
                    if(vector_balas[i]->getTipo() == 2){
                        vector_balas[i]->disparar_angulo();
                    }
                    else{
                        if(vector_balas[i]->getTipo() == 3){
                            if(player.getMoviendo()){
                                vector_balas[i]->disparar_canyon(player.getLastMove());
                                player.setMoviendo(false);
                            }
                            if(reloj.getElapsedTime().asSeconds() > 1.0f){

                                vector_balas[i]->escalarCanyon();
                                vector_balas[i]->moverbala(contador);
                                reloj.restart();
                                contador++;
                                if(contador >= 5){
                                    vector_balas[i]->disparar();
                                }
                            }
                        }
                        else{
                            if(vector_balas[i]->getTipo() == 4){
                                if(reloj.getElapsedTime().asSeconds() <= 0.5f){
                                    vector_balas[i]->disparar_bomba(1);
                                }
                                else{
                                    if(reloj.getElapsedTime().asSeconds() >= 0.8f){
                                        vector_balas[i]->disparar_canyon(sf::Vector2f(0,-900));
                                        bomba_viva = false;
                                    }
                                    else{
                                        if(explotado == false){
                                            vector_balas[i]->disparar_bomba(2);
                                            explotado = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if(vector_balas[i]->getY() < -100){
                    delete vector_balas[i];
                    vector_balas.erase(vector_balas.begin() + i);
                    //std::cout << "eliminado" << std::endl;
                    //std::cout << bomba_viva << std::endl;
                    contador = 0;
                    reloj.restart();
                }
                else{
                    if(vector_balas[i]->getTipo() == 3 && contador >=  6 ){
                        vector_balas[i]->disparar();
                        player.setMunicion(1);
                    }
                    else{
                        
                    }
                }
            }
        }
        player.draw(window);
        window.display();

    }

    return 0;
}