/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   nave.h
 * Author: angel
 *
 * Created on 21 de marzo de 2018, 11:26
 */

#ifndef NAVE_H
#define NAVE_H
#include <SFML/Graphics.hpp>

class nave {
   
public:
    nave();
    nave(const nave& orig);
    virtual ~nave();
    void move(sf::Vector2f);
    void draw(sf::RenderWindow&);
    sf::Sprite getShiprite();
    int getX();
    int getY();
    int getMunicion();
    void setMunicion(int);
    sf::Vector2f getLastMove();
    void setLastMove(sf::Vector2f);
    void setMoviendo(bool);
    bool getMoviendo();
    int getVelocidadNave();
    void setVelocidadNave(int);
private:
    int municion;
    sf::Sprite sprite;
    sf::Texture tex;
    sf::Vector2f lastmove;
    bool en_movimiento;
    int velocidad_nave;
};

#endif /* NAVE_H */

