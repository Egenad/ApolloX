/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bala.cpp
 * Author: angel
 * 
 * Created on 21 de marzo de 2018, 11:19
 */

#include "bala.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <math.h>

const float degree2radian = (3.14159f / 180.0f);

bala::bala(sf::Vector2f tamanyo, int n, float velo) {
    bullet.setSize(tamanyo);
    bullet.setFillColor(sf::Color::Blue);
    tipo_bala = n;
    velocidad = velo;
}

bala::bala(sf::Vector2f tamanyo, int n, float angul, float velo) {
    bullet.setSize(tamanyo);
    bullet.setFillColor(sf::Color::Blue);
    tipo_bala = n;
    angulo = angul;
    velocidad = velo;
}

bala::bala(const bala& orig) {
}

bala::~bala() {
}

void bala::disparar(){
    bullet.move(0,-velocidad);
}

void bala::disparar_angulo(){
    bullet.move(cos(degree2radian*angulo)*velocidad,-velocidad*sin(degree2radian*angulo));
}

void bala::disparar_canyon(sf::Vector2f shiposition){
    bullet.move(shiposition);
}

void bala::disparar_bomba(int n){
    switch(n){
        case 1:
            bullet.move(0, -velocidad);
        break;
        case 2:
            bullet.scale(8, 4);
            bullet.move(-20,0);
        break;
    }
}

void bala::moverbala(int contador){
    switch(contador){
        case 0:
            bullet.move(7, 0);
            break;
        case 1:
            bullet.move(5, 0);
            break;
        case 2:
            bullet.move(1, 0);
            break;
        case 3:
            bullet.move(1, 0);
            break;
        case 4:
            bullet.move(0, 0);
            break;
    }
    
}

void bala::escalarCanyon(){
    bullet.scale(0.5,1);
    
}

void bala::draw(sf::RenderWindow& window){
    window.draw(bullet);
}

void bala::nuevaPosicion(sf::Vector2f newpos){
    bullet.setPosition(newpos);
}

int bala::getX(){
    return bullet.getPosition().x;
}

int bala::getY(){
    return bullet.getPosition().y;
}

int bala::getTipo(){
    return tipo_bala;
}

