/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alien.cpp
 * Author: raquel
 * 
 * Created on 26 de marzo de 2018, 21:34
 */

#include "Alien.h"



Alien::Alien(m2D::Texture &textura, int tip) {
    type=tip; //tipo de movimiento
    sprite.setTexture(textura);
    sprite.setTextureRect(280,70, 100, 110);
    position.setVectorX(rand()%(600-100));
    position.setVectorY(-50);
    sprite.setPosition(position.getVectorX(),position.getVectorY());   

}

Alien::Alien(const Alien& orig) {
}

Alien::~Alien() {
}

void Alien::setPos(int x, int y){
    sprite.setPosition(x,y);
}
 int Alien::getX(){
     return sprite.getPositionX();
}
 int Alien::getY(){
     return sprite.getPositionY();
        
}
void Alien::draw(m2D::RenderWindow &window){
    window.draw(sprite);
}

m2D::Sprite& Alien::getShape(){
    return sprite;
}

m2D::Vector2f Alien::getPos(){
    return position;
}

void Alien::dispara(m2D::Texture &textura){
    if(dis.getElapsedTimeAsSeconds()>1){
        Bala *newBullet= new Bala(textura);//TAMAÑO DE BALA
        newBullet->setPos(m2D::Vector2f(sprite.getPositionX()+50,sprite.getPositionY()+20));//POSICION DE LA BALA
        balas.push_back(newBullet);//VECTOR DE BALAS
        dis.restart();
    }

}

void Alien::dibujaBalas(m2D::RenderWindow &window, Nave &nave){
        for(int n=0; n< balas.size(); n++){//DIBUJAMOS LAS BALAS      
            balas[n]->draw(window);
            balas[n]->fire(6);//LE PASAMOS LA VELOCIDAD DE DISPARO
        }
        
        /*for(int k=0;k< balas.size();k++){
            bool cola=false;
            cola=nave.checkColl(*balas[k]); //LE PASAMOS LA BALA CON LA QUE COLOSIONA
            if(cola){
                delete balas[k];
                balas.erase(balas.begin()+k);
                
            }
        }*/
}

void Alien::mov(float grados){
    sprite.move(sin(grados),1);

}

int Alien::getTipo(){
    return type;
}

