/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nave.cpp
 * Author: raquel
 * 
 * Created on 27 de febrero de 2018, 18:18
 */
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Nave.h"
#include "Clock.h"
#include "Sprite.h"
#include "Vector2f.h"

Nave::Nave (int x, int y, m2D::Sprite &s ){
    position.setVectorX(x);
    position.setVectorY(y);
    state=2;
    vida=1000;
    sprite = s;
    sprite.setPosition(x, y);
}
Nave::Nave(const Nave& orig) {
}

Nave::~Nave() {
}
void Nave::setSprite(m2D::Sprite s){
    sprite = s;
    sprite.setPosition(position.getVectorX(), position.getVectorY());
}
void Nave::setState(int d){
    state=d;
}
m2D::Vector2f Nave::getPosition(){
    return position;
}
m2D::Sprite& Nave::getSprite(){
    return sprite;
}
int Nave::getState(){
    return state;
}
void Nave::setPosition(int x, int y){
    position.setVectorX(x);
    position.setVectorY(y);
    
    sprite.setPosition(position.getVectorX(),position.getVectorY());
}

bool Nave::checkColl(Bala &bullet){//COLISIONES
        //ESTAMOS COLISIONANDO 100%
    bool cola=false;
    if(sprite.getGlobalBounds().intersects(bullet.returnShape().getGlobalBounds())){ 
        //detectar lo de la vida
        cola=true;
        vida = vida - 225;
        if(vida<=0){
           sprite.setPosition(10000,10000);
        }
    }
    
    return cola;
}

bool Nave::checkCollMete(Meteorito& meteorito){
    // if(bullet.getLeft() > nave.getPosition().x && bullet.getRight() > nave.getPosition().x && bullet.getTop() < nave.getPosition().y + nave.getSize().y && bullet.getBottom() > nave.getPosition().y){
        //ESTAMOS COLISIONANDO 100%
    bool cola=false;
    if(sprite.getGlobalBounds().intersects(meteorito.returnShape().getGlobalBounds())){ 
        //detectar lo de la vida
        cola=true;
        
        vida = vida - 50;
        if(vida<=0){
           sprite.setPosition(10000,10000);
        }
    }
    
    return cola;
}